//.VN MILIK NINA KAWAI AHH YMATE KUDASAI

//KETIKA ADA YANG TOXIC
exports.vnToxic = [
 //dosa pantex
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735078893207.mp3",
// heeh
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735078939289.mp3",
// jangan toxic om
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079034571.mp3"
]
exports.vnMenu = [
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735463128872.mp3",
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735463188399.mp3",
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735498314898.mp3"
]
exports.vnOwner = [ 
 // ga ada
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079122237.mp3",
// gaboleh
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079151914.mp3",
// gamau
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079176281.mp3"
]
exports.vnAra = [ 
 // ara ara
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079339321.mp3",
// ara koplok
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079308614.mp3"
    ]
exports.vnBot = [ 
// ada apa kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079669571.mp3",
// iya kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079705038.mp3",
// kenapa kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079750288.mp3",
// oyy
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079791762.mp3",
 // ngomong apaan sih
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079832258.mp3",
// lu siapa njir
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079865610.mp3"
    ]
exports.vnSalam = [ "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735079965592.mp3"]
exports.vnSpam = [ "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080035325.mp3"]
exports.vnPagi = [ "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080171985.mp3"]
exports.vnSiang = [ 
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080118571.mp3" ]
exports.vnMalam = [ 
 "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080171985.mp3"]
exports.vnSubuh = [ "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080171985.mp3"]

exports.vnKawai = [ "https://cdn.filestackcontent.com/zHMFviWeT6eDOvu3eJe3"]
exports.vnLove = [ 
// lopyutu
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080673767.mp3",
// lopyu kambing
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735080706602.mp3"    ]



